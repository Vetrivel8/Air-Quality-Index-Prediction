"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Loader2, Brain, TrendingUp } from "lucide-react"

interface PredictionResult {
  predicted_aqi: number
  confidence: number
  model_used: string
  timestamp: string
}

const getAQICategory = (aqi: number) => {
  if (aqi <= 50) return { category: "Good", color: "aqi-good" }
  if (aqi <= 100) return { category: "Moderate", color: "aqi-moderate" }
  if (aqi <= 200) return { category: "Poor", color: "aqi-poor" }
  if (aqi <= 300) return { category: "Very Poor", color: "aqi-very-poor" }
  return { category: "Severe", color: "aqi-severe" }
}

export default function PredictionForm() {
  const [formData, setFormData] = useState({
    pm25: "",
    pm10: "",
    no2: "",
    so2: "",
    co: "",
    o3: "",
    temperature: "",
    humidity: "",
    wind_speed: "",
    pressure: "",
  })
  const [prediction, setPrediction] = useState<PredictionResult | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState("")

  const handleInputChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setError("")
    setPrediction(null)

    try {
      const response = await fetch("/api/predict", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          pm25: Number.parseFloat(formData.pm25),
          pm10: Number.parseFloat(formData.pm10),
          no2: Number.parseFloat(formData.no2),
          so2: Number.parseFloat(formData.so2),
          co: Number.parseFloat(formData.co),
          o3: Number.parseFloat(formData.o3),
          temperature: Number.parseFloat(formData.temperature),
          humidity: Number.parseFloat(formData.humidity),
          wind_speed: Number.parseFloat(formData.wind_speed),
          pressure: Number.parseFloat(formData.pressure),
        }),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "Prediction failed")
      }

      setPrediction(data.prediction)
    } catch (err) {
      setError(err instanceof Error ? err.message : "An error occurred")
    } finally {
      setIsLoading(false)
    }
  }

  const aqiCategory = prediction ? getAQICategory(prediction.predicted_aqi) : null

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Brain className="h-5 w-5" />
            AQI Prediction Form
          </CardTitle>
          <CardDescription>Enter pollutant and weather data to get AI-powered AQI predictions</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="pm25">PM2.5 (μg/m³)</Label>
                <Input
                  id="pm25"
                  type="number"
                  step="0.1"
                  value={formData.pm25}
                  onChange={(e) => handleInputChange("pm25", e.target.value)}
                  placeholder="0-500"
                  required
                />
              </div>
              <div>
                <Label htmlFor="pm10">PM10 (μg/m³)</Label>
                <Input
                  id="pm10"
                  type="number"
                  step="0.1"
                  value={formData.pm10}
                  onChange={(e) => handleInputChange("pm10", e.target.value)}
                  placeholder="0-600"
                  required
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="no2">NO₂ (μg/m³)</Label>
                <Input
                  id="no2"
                  type="number"
                  step="0.1"
                  value={formData.no2}
                  onChange={(e) => handleInputChange("no2", e.target.value)}
                  placeholder="0-200"
                  required
                />
              </div>
              <div>
                <Label htmlFor="so2">SO₂ (μg/m³)</Label>
                <Input
                  id="so2"
                  type="number"
                  step="0.1"
                  value={formData.so2}
                  onChange={(e) => handleInputChange("so2", e.target.value)}
                  placeholder="0-500"
                  required
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="co">CO (mg/m³)</Label>
                <Input
                  id="co"
                  type="number"
                  step="0.1"
                  value={formData.co}
                  onChange={(e) => handleInputChange("co", e.target.value)}
                  placeholder="0-30"
                  required
                />
              </div>
              <div>
                <Label htmlFor="o3">O₃ (μg/m³)</Label>
                <Input
                  id="o3"
                  type="number"
                  step="0.1"
                  value={formData.o3}
                  onChange={(e) => handleInputChange("o3", e.target.value)}
                  placeholder="0-240"
                  required
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="temperature">Temperature (°C)</Label>
                <Input
                  id="temperature"
                  type="number"
                  step="0.1"
                  value={formData.temperature}
                  onChange={(e) => handleInputChange("temperature", e.target.value)}
                  placeholder="-40 to 50"
                  required
                />
              </div>
              <div>
                <Label htmlFor="humidity">Humidity (%)</Label>
                <Input
                  id="humidity"
                  type="number"
                  step="0.1"
                  value={formData.humidity}
                  onChange={(e) => handleInputChange("humidity", e.target.value)}
                  placeholder="0-100"
                  required
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="wind_speed">Wind Speed (m/s)</Label>
                <Input
                  id="wind_speed"
                  type="number"
                  step="0.1"
                  value={formData.wind_speed}
                  onChange={(e) => handleInputChange("wind_speed", e.target.value)}
                  placeholder="0-50"
                  required
                />
              </div>
              <div>
                <Label htmlFor="pressure">Pressure (hPa)</Label>
                <Input
                  id="pressure"
                  type="number"
                  step="0.1"
                  value={formData.pressure}
                  onChange={(e) => handleInputChange("pressure", e.target.value)}
                  placeholder="900-1100"
                  required
                />
              </div>
            </div>

            {error && <div className="text-destructive text-sm bg-destructive/10 p-3 rounded-md">{error}</div>}

            <Button type="submit" className="w-full" disabled={isLoading}>
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Predicting...
                </>
              ) : (
                <>
                  <TrendingUp className="mr-2 h-4 w-4" />
                  Predict AQI
                </>
              )}
            </Button>
          </form>
        </CardContent>
      </Card>

      {prediction && (
        <Card>
          <CardHeader>
            <CardTitle>Prediction Result</CardTitle>
            <CardDescription>AI-powered AQI forecast</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="text-center">
              <div className="text-6xl font-bold mb-2">{prediction.predicted_aqi}</div>
              {aqiCategory && (
                <Badge className={`${aqiCategory.color} text-lg px-4 py-2 mb-4`}>{aqiCategory.category}</Badge>
              )}
            </div>

            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <div className="text-muted-foreground">Confidence</div>
                <div className="font-semibold">{prediction.confidence.toFixed(1)}%</div>
              </div>
              <div>
                <div className="text-muted-foreground">Model</div>
                <div className="font-semibold">{prediction.model_used}</div>
              </div>
            </div>

            <div className="text-xs text-muted-foreground">
              Predicted at: {new Date(prediction.timestamp).toLocaleString()}
            </div>

            <div className="mt-4 p-4 bg-muted/50 rounded-lg">
              <h4 className="font-semibold mb-2">Health Recommendations</h4>
              <p className="text-sm text-muted-foreground">
                {prediction.predicted_aqi <= 50 && "Air quality is good. Ideal for outdoor activities."}
                {prediction.predicted_aqi > 50 &&
                  prediction.predicted_aqi <= 100 &&
                  "Air quality is moderate. Sensitive individuals should consider limiting outdoor activities."}
                {prediction.predicted_aqi > 100 &&
                  prediction.predicted_aqi <= 200 &&
                  "Air quality is poor. Limit outdoor activities and consider wearing a mask."}
                {prediction.predicted_aqi > 200 &&
                  prediction.predicted_aqi <= 300 &&
                  "Air quality is very poor. Avoid outdoor activities and stay indoors."}
                {prediction.predicted_aqi > 300 &&
                  "Air quality is severe. Stay indoors and use air purifiers if available."}
              </p>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
