"""
Complete AQI Prediction Pipeline Runner
This script runs the entire pipeline from data generation to model training
"""

import subprocess
import sys
import os
from datetime import datetime

def run_script(script_path, description):
    """Run a Python script and handle errors"""
    print(f"\n{'='*60}")
    print(f"RUNNING: {description}")
    print(f"Script: {script_path}")
    print(f"{'='*60}")
    
    try:
        result = subprocess.run([sys.executable, script_path], 
                              capture_output=True, text=True, check=True)
        print("✓ SUCCESS")
        if result.stdout:
            print("Output:", result.stdout[-500:])  # Last 500 chars
        return True
    except subprocess.CalledProcessError as e:
        print("✗ FAILED")
        print("Error:", e.stderr)
        return False
    except FileNotFoundError:
        print(f"✗ SCRIPT NOT FOUND: {script_path}")
        return False

def main():
    """Run the complete AQI prediction pipeline"""
    print("🌬️ AQI PREDICTION SYSTEM - COMPLETE PIPELINE")
    print(f"Started at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    
    # Define pipeline steps
    pipeline_steps = [
        ("scripts/01_generate_dataset.py", "Generate Synthetic AQI Dataset"),
        ("scripts/02_data_preprocessing.py", "Data Preprocessing & Feature Engineering"),
        ("scripts/03_train_random_forest.py", "Train Random Forest Model"),
        ("scripts/04_train_lstm.py", "Train LSTM Time Series Model"),
        ("scripts/05_model_evaluation.py", "Model Evaluation & Comparison"),
        ("scripts/06_forecasting_engine.py", "Test Forecasting Engine")
    ]
    
    # Track results
    results = []
    
    # Run each step
    for script_path, description in pipeline_steps:
        success = run_script(script_path, description)
        results.append((description, success))
        
        if not success:
            print(f"\n❌ Pipeline failed at: {description}")
            print("Please check the error messages above and fix any issues.")
            break
    
    # Summary
    print(f"\n{'='*60}")
    print("PIPELINE SUMMARY")
    print(f"{'='*60}")
    
    for description, success in results:
        status = "✓ PASSED" if success else "✗ FAILED"
        print(f"{status}: {description}")
    
    successful_steps = sum(1 for _, success in results if success)
    total_steps = len(results)
    
    print(f"\nCompleted: {successful_steps}/{total_steps} steps")
    
    if successful_steps == len(pipeline_steps):
        print("\n🎉 PIPELINE COMPLETED SUCCESSFULLY!")
        print("\nNext steps:")
        print("1. Run 'streamlit run streamlit_app.py' to launch the dashboard")
        print("2. Or use the forecasting engine directly in your applications")
        print("3. Check the generated plots and evaluation reports")
    else:
        print(f"\n⚠️  Pipeline incomplete. {len(pipeline_steps) - successful_steps} steps failed.")
    
    print(f"\nFinished at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

if __name__ == "__main__":
    main()
