"""
FastAPI server for AQI prediction API
Run with: uvicorn api_server:app --reload
"""

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List, Dict, Optional
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import sys
import os

# Add scripts directory to path
sys.path.append('scripts')

from scripts.forecasting_engine import AQIForecaster

app = FastAPI(
    title="AQI Prediction API",
    description="API for Air Quality Index prediction and forecasting",
    version="1.0.0"
)

# Global forecaster instance
forecaster = None

@app.on_event("startup")
async def startup_event():
    """Load models on startup"""
    global forecaster
    forecaster = AQIForecaster()
    forecaster.load_models()

# Pydantic models for API
class CurrentDataPoint(BaseModel):
    datetime: str
    temperature: float
    humidity: float
    wind_speed: float
    pressure: float
    rainfall: float
    pm25: float
    pm10: float
    no2: float
    so2: float
    co: float
    o3: float

class ForecastRequest(BaseModel):
    current_data: List[CurrentDataPoint]
    hours_ahead: Optional[int] = 24
    model: Optional[str] = "both"  # "rf", "lstm", or "both"

class ForecastResponse(BaseModel):
    datetime: str
    predicted_aqi: float
    category: str
    color: str
    model: str

class AQIResponse(BaseModel):
    aqi: float
    category: str
    color: str
    health_recommendations: List[str]

@app.get("/")
async def root():
    """Root endpoint"""
    return {
        "message": "AQI Prediction API",
        "version": "1.0.0",
        "endpoints": {
            "/predict": "Predict AQI from current conditions",
            "/forecast": "Generate 24-hour AQI forecast",
            "/health": "Get health recommendations for AQI value",
            "/docs": "API documentation"
        }
    }

@app.post("/predict", response_model=AQIResponse)
async def predict_aqi(data: CurrentDataPoint):
    """Predict AQI from current conditions"""
    if not forecaster or not forecaster.models_loaded:
        raise HTTPException(status_code=503, detail="Models not loaded")
    
    try:
        # Convert to DataFrame
        df = pd.DataFrame([data.dict()])
        df['datetime'] = pd.to_datetime(df['datetime'])
        
        # Use Random Forest for single prediction
        forecasts = forecaster.forecast_aqi(df, hours_ahead=1, model='rf')
        
        if 'Random Forest' not in forecasts or not forecasts['Random Forest']:
            raise HTTPException(status_code=500, detail="Prediction failed")
        
        prediction = forecasts['Random Forest'][0]
        category, color = forecaster.categorize_aqi(prediction['predicted_aqi'])
        recommendations = forecaster.get_health_recommendations(category)
        
        return AQIResponse(
            aqi=prediction['predicted_aqi'],
            category=category,
            color=color,
            health_recommendations=recommendations
        )
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Prediction error: {str(e)}")

@app.post("/forecast")
async def forecast_aqi(request: ForecastRequest):
    """Generate AQI forecast"""
    if not forecaster or not forecaster.models_loaded:
        raise HTTPException(status_code=503, detail="Models not loaded")
    
    try:
        # Convert to DataFrame
        data_dicts = [item.dict() for item in request.current_data]
        df = pd.DataFrame(data_dicts)
        df['datetime'] = pd.to_datetime(df['datetime'])
        df = df.sort_values('datetime')
        
        # Generate forecast
        forecasts = forecaster.forecast_aqi(
            df, 
            hours_ahead=request.hours_ahead, 
            model=request.model
        )
        
        # Format response
        response = {}
        for model_name, model_forecasts in forecasts.items():
            response[model_name] = [
                ForecastResponse(
                    datetime=f['datetime'].isoformat(),
                    predicted_aqi=f['predicted_aqi'],
                    category=f['category'],
                    color=f['color'],
                    model=f['model']
                ) for f in model_forecasts
            ]
        
        return response
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Forecast error: {str(e)}")

@app.get("/health/{aqi_value}", response_model=Dict[str, any])
async def get_health_recommendations(aqi_value: float):
    """Get health recommendations for AQI value"""
    if not forecaster:
        raise HTTPException(status_code=503, detail="Service not available")
    
    try:
        category, color = forecaster.categorize_aqi(aqi_value)
        recommendations = forecaster.get_health_recommendations(category)
        
        return {
            "aqi": aqi_value,
            "category": category,
            "color": color,
            "health_recommendations": recommendations
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error: {str(e)}")

@app.get("/status")
async def get_status():
    """Get API status"""
    return {
        "status": "online",
        "models_loaded": forecaster.models_loaded if forecaster else False,
        "timestamp": datetime.now().isoformat()
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
