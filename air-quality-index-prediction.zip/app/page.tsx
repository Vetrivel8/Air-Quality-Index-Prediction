"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area } from "recharts"
import {
  TrendingUp,
  AlertTriangle,
  CheckCircle,
  Activity,
  Leaf,
  Brain,
  Shield,
  MapPin,
  Bell,
  Users,
  Smartphone,
  Building,
  Lightbulb,
  Mail,
  Phone,
  Menu,
  X,
  Star,
  Globe,
  BarChart3,
  Zap,
  Eye,
} from "lucide-react"

// Mock data generators
const generateMockData = () => {
  const now = new Date()
  const data = []

  for (let i = 0; i < 24; i++) {
    const time = new Date(now.getTime() - (23 - i) * 60 * 60 * 1000)
    data.push({
      time: time.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" }),
      datetime: time,
      aqi: Math.floor(Math.random() * 200) + 50,
      pm25: Math.random() * 100 + 20,
      pm10: Math.random() * 150 + 30,
      no2: Math.random() * 80 + 10,
      so2: Math.random() * 50 + 5,
      co: Math.random() * 10 + 1,
      o3: Math.random() * 120 + 20,
    })
  }

  return data
}

const generateForecastData = () => {
  const now = new Date()
  const data = []

  for (let i = 1; i <= 168; i++) {
    // 7 days
    const time = new Date(now.getTime() + i * 60 * 60 * 1000)
    data.push({
      time:
        i <= 24
          ? time.toLocaleTimeString("en-US", { hour: "2-digit" })
          : time.toLocaleDateString("en-US", { month: "short", day: "numeric" }),
      datetime: time,
      aqi: Math.floor(Math.random() * 150) + 40,
      confidence: Math.random() * 30 + 70,
    })
  }

  return data
}

const cities = [
  { name: "New Delhi", aqi: 287, lat: 28.6139, lng: 77.209 },
  { name: "Mumbai", aqi: 156, lat: 19.076, lng: 72.8777 },
  { name: "Beijing", aqi: 201, lat: 39.9042, lng: 116.4074 },
  { name: "Los Angeles", aqi: 89, lat: 34.0522, lng: -118.2437 },
  { name: "London", aqi: 67, lat: 51.5074, lng: -0.1278 },
]

const getAQICategory = (aqi: number) => {
  if (aqi <= 50) return { category: "Good", color: "aqi-good" }
  if (aqi <= 100) return { category: "Moderate", color: "aqi-moderate" }
  if (aqi <= 200) return { category: "Poor", color: "aqi-poor" }
  if (aqi <= 300) return { category: "Very Poor", color: "aqi-very-poor" }
  return { category: "Severe", color: "aqi-severe" }
}

export default function BreatheSafeWebsite() {
  const [historicalData, setHistoricalData] = useState(generateMockData())
  const [forecastData, setForecastData] = useState<any[]>([])
  const [selectedCity, setSelectedCity] = useState(cities[0])
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [activeTab, setActiveTab] = useState("24h")
  const [email, setEmail] = useState("")
  const [isSubscribed, setIsSubscribed] = useState(false)
  const [contactForm, setContactForm] = useState({
    name: "",
    organization: "",
    email: "",
    message: "",
  })
  const [isContactSubmitted, setIsContactSubmitted] = useState(false)

  const currentAQI = getAQICategory(selectedCity.aqi)

  useEffect(() => {
    setForecastData(generateForecastData())
  }, [])

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId)
    if (element) {
      element.scrollIntoView({ behavior: "smooth" })
    }
    setIsMenuOpen(false)
  }

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault()
    if (!email) return

    console.log("[v0] Newsletter subscription:", email)
    setIsSubscribed(true)
    setEmail("")
    setTimeout(() => setIsSubscribed(false), 3000)
  }

  const handleContactSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    console.log("[v0] Contact form submission:", contactForm)
    setIsContactSubmitted(true)
    setContactForm({ name: "", organization: "", email: "", message: "" })
    setTimeout(() => setIsContactSubmitted(false), 3000)
  }

  const handleCheckAQI = () => {
    console.log("[v0] Check AQI button clicked")
    scrollToSection("dashboard")
  }

  const handleGetAlerts = () => {
    console.log("[v0] Get Alerts button clicked")
    scrollToSection("contact")
  }

  const handleCitySelect = (city: (typeof cities)[0]) => {
    console.log("[v0] City selected:", city.name)
    setSelectedCity(city)
    setHistoricalData(generateMockData())
    setForecastData(generateForecastData())
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="fixed top-0 w-full bg-background/80 backdrop-blur-md border-b border-border z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-2">
              <Leaf className="h-8 w-8 text-primary" />
              <span className="text-xl font-bold text-gradient">BREATHESAFE</span>
            </div>

            <div className="hidden md:flex items-center space-x-8">
              <button
                onClick={() => scrollToSection("features")}
                className="text-muted-foreground hover:text-foreground transition-colors"
              >
                Features
              </button>
              <button
                onClick={() => scrollToSection("dashboard")}
                className="text-muted-foreground hover:text-foreground transition-colors"
              >
                Dashboard
              </button>
              <button
                onClick={() => scrollToSection("future")}
                className="text-muted-foreground hover:text-foreground transition-colors"
              >
                Future
              </button>
              <button
                onClick={() => scrollToSection("contact")}
                className="text-muted-foreground hover:text-foreground transition-colors"
              >
                Contact
              </button>
              <Button onClick={() => scrollToSection("contact")}>Get Started</Button>
            </div>

            <button className="md:hidden" onClick={() => setIsMenuOpen(!isMenuOpen)}>
              {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>

        {/* Mobile menu */}
        {isMenuOpen && (
          <div className="md:hidden bg-card border-t border-border">
            <div className="px-2 pt-2 pb-3 space-y-1">
              <button
                onClick={() => scrollToSection("features")}
                className="block w-full text-left px-3 py-2 text-muted-foreground hover:text-foreground"
              >
                Features
              </button>
              <button
                onClick={() => scrollToSection("dashboard")}
                className="block w-full text-left px-3 py-2 text-muted-foreground hover:text-foreground"
              >
                Dashboard
              </button>
              <button
                onClick={() => scrollToSection("future")}
                className="block w-full text-left px-3 py-2 text-muted-foreground hover:text-foreground"
              >
                Future
              </button>
              <button
                onClick={() => scrollToSection("contact")}
                className="block w-full text-left px-3 py-2 text-muted-foreground hover:text-foreground"
              >
                Contact
              </button>
              <div className="px-3 py-2">
                <Button className="w-full" onClick={() => scrollToSection("contact")}>
                  Get Started
                </Button>
              </div>
            </div>
          </div>
        )}
      </nav>

      {/* Hero Section */}
      <section className="pt-24 pb-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto text-center">
          <div className="floating-animation mb-8">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-primary/10 rounded-full text-primary text-sm font-medium">
              <Brain className="h-4 w-4" />
              AI-Powered Forecasting
            </div>
          </div>

          <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold text-balance mb-6">
            Predict today, <span className="text-gradient">breathe better</span> tomorrow
          </h1>

          <p className="text-xl md:text-2xl text-muted-foreground text-balance mb-8 max-w-3xl mx-auto">
            Advanced AI-powered air quality monitoring and forecasting platform that helps communities stay ahead of
            pollution spikes and protect their health.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
            <Button size="lg" className="text-lg px-8 py-6" onClick={handleCheckAQI}>
              <Activity className="mr-2 h-5 w-5" />
              Check AQI Now
            </Button>
            <Button size="lg" variant="outline" className="text-lg px-8 py-6 bg-transparent" onClick={handleGetAlerts}>
              <Bell className="mr-2 h-5 w-5" />
              Get Alerts
            </Button>
          </div>

          {/* Animated cityscape visualization */}
          <div className="relative max-w-4xl mx-auto">
            <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
              {cities.map((city, index) => {
                const category = getAQICategory(city.aqi)
                return (
                  <Card
                    key={city.name}
                    className="hover:scale-105 transition-transform cursor-pointer"
                    onClick={() => handleCitySelect(city)}
                  >
                    <CardContent className="p-4 text-center">
                      <MapPin className="h-6 w-6 mx-auto mb-2 text-muted-foreground" />
                      <div className="font-semibold text-sm">{city.name}</div>
                      <div className="text-2xl font-bold my-1">{city.aqi}</div>
                      <Badge className={`${category.color} text-xs`}>{category.category}</Badge>
                    </CardContent>
                  </Card>
                )
              })}
            </div>
          </div>
        </div>
      </section>

      {/* Problem Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-card/50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">The Growing Air Quality Crisis</h2>
            <p className="text-xl text-muted-foreground text-balance max-w-3xl mx-auto">
              Urbanization and industrial growth have led to unprecedented air pollution levels, directly impacting
              public health worldwide.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-destructive/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <Building className="h-8 w-8 text-destructive" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Urbanization</h3>
              <p className="text-muted-foreground">
                Rapid city growth increases vehicle emissions and industrial pollution
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-warning/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <AlertTriangle className="h-8 w-8 text-warning" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Health Impact</h3>
              <p className="text-muted-foreground">7 million premature deaths annually due to air pollution exposure</p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <Eye className="h-8 w-8 text-primary" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Lack of Foresight</h3>
              <p className="text-muted-foreground">Current systems only report past data, not future predictions</p>
            </div>
          </div>

          {/* Pollutants showcase */}
          <div className="mt-16">
            <h3 className="text-2xl font-bold text-center mb-8">Key Pollutants We Monitor</h3>
            <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
              {[
                { name: "PM2.5", desc: "Fine particles", color: "chart-1" },
                { name: "PM10", desc: "Coarse particles", color: "chart-2" },
                { name: "CO", desc: "Carbon monoxide", color: "chart-3" },
                { name: "NO₂", desc: "Nitrogen dioxide", color: "chart-4" },
                { name: "O₃", desc: "Ground-level ozone", color: "chart-5" },
              ].map((pollutant) => (
                <Card key={pollutant.name} className="text-center hover:scale-105 transition-transform">
                  <CardContent className="p-4">
                    <div className="text-2xl font-bold mb-1">{pollutant.name}</div>
                    <div className="text-sm text-muted-foreground">{pollutant.desc}</div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Solution Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">AI-Powered Solution</h2>
            <p className="text-xl text-muted-foreground text-balance max-w-3xl mx-auto">
              Our advanced machine learning models analyze multiple data sources to provide accurate air quality
              forecasts up to 7 days in advance.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center flex-shrink-0">
                  <BarChart3 className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <h3 className="text-xl font-semibold mb-2">Multi-Source Data Integration</h3>
                  <p className="text-muted-foreground">
                    Weather stations, satellite imagery, traffic patterns, and industrial emissions
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center flex-shrink-0">
                  <Brain className="h-6 w-6 text-accent" />
                </div>
                <div>
                  <h3 className="text-xl font-semibold mb-2">Advanced AI Models</h3>
                  <p className="text-muted-foreground">
                    Random Forest and LSTM neural networks for accurate predictions
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-eco-teal/10 rounded-lg flex items-center justify-center flex-shrink-0">
                  <Zap className="h-6 w-6" style={{ color: "var(--color-eco-teal)" }} />
                </div>
                <div>
                  <h3 className="text-xl font-semibold mb-2">Real-Time Processing</h3>
                  <p className="text-muted-foreground">Continuous model updates with live data streams</p>
                </div>
              </div>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>AI Model Performance</CardTitle>
                <CardDescription>Prediction accuracy over time</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={historicalData.slice(-12)}>
                      <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                      <XAxis dataKey="time" stroke="hsl(var(--muted-foreground))" fontSize={12} />
                      <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} />
                      <Tooltip
                        contentStyle={{
                          backgroundColor: "hsl(var(--card))",
                          border: "1px solid hsl(var(--border))",
                          borderRadius: "8px",
                        }}
                      />
                      <Line
                        type="monotone"
                        dataKey="aqi"
                        stroke="hsl(var(--primary))"
                        strokeWidth={3}
                        dot={{ fill: "hsl(var(--primary))", strokeWidth: 2, r: 4 }}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-16 px-4 sm:px-6 lg:px-8 bg-card/50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Powerful Features</h2>
            <p className="text-xl text-muted-foreground text-balance max-w-3xl mx-auto">
              Comprehensive air quality monitoring and forecasting tools designed for individuals, communities, and
              organizations.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                icon: TrendingUp,
                title: "Real-Time Predictions",
                description: "Get accurate AQI forecasts up to 7 days in advance with confidence intervals",
                color: "primary",
              },
              {
                icon: Bell,
                title: "Early Spike Detection",
                description: "Receive alerts before pollution levels rise, giving you time to take protective action",
                color: "accent",
              },
              {
                icon: BarChart3,
                title: "Visual Dashboards",
                description: "Interactive charts and maps showing air quality trends and patterns",
                color: "eco-teal",
              },
              {
                icon: Globe,
                title: "Multi-City Coverage",
                description: "Monitor air quality across multiple cities and regions simultaneously",
                color: "chart-4",
              },
              {
                icon: Zap,
                title: "Scalable Platform",
                description: "From personal use to enterprise solutions, scales to meet your needs",
                color: "chart-5",
              },
              {
                icon: Shield,
                title: "Health Recommendations",
                description: "Personalized advice based on current and predicted air quality conditions",
                color: "eco-green",
              },
            ].map((feature, index) => (
              <Card key={index} className="group hover:scale-105 transition-all duration-300 hover:shadow-lg">
                <CardContent className="p-6">
                  <div
                    className={`w-12 h-12 rounded-lg flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}
                    style={{ backgroundColor: `var(--color-${feature.color})/0.1` }}
                  >
                    <feature.icon className="h-6 w-6" style={{ color: `var(--color-${feature.color})` }} />
                  </div>
                  <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
                  <p className="text-muted-foreground">{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Live Dashboard Section */}
      <section id="dashboard" className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Live AQI Dashboard</h2>
            <p className="text-xl text-muted-foreground text-balance max-w-3xl mx-auto">
              Real-time air quality monitoring with interactive maps and detailed analytics for {selectedCity.name}.
            </p>
          </div>

          {/* Current AQI Status */}
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 mb-8">
            <Card className="lg:col-span-1">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <MapPin className="h-5 w-5" />
                  {selectedCity.name}
                </CardTitle>
              </CardHeader>
              <CardContent className="text-center">
                <div className="text-5xl font-bold mb-2">{selectedCity.aqi}</div>
                <Badge className={`${currentAQI.color} text-lg px-4 py-2 mb-4`}>{currentAQI.category}</Badge>
                <Progress value={(selectedCity.aqi / 500) * 100} className="h-3" />
              </CardContent>
            </Card>

            <Card className="lg:col-span-3">
              <CardHeader>
                <CardTitle>7-Day Forecast</CardTitle>
                <CardDescription>Predicted AQI levels with confidence intervals</CardDescription>
              </CardHeader>
              <CardContent>
                <Tabs value={activeTab} onValueChange={setActiveTab}>
                  <TabsList className="grid w-full grid-cols-2">
                    <TabsTrigger value="24h">Next 24 Hours</TabsTrigger>
                    <TabsTrigger value="7d">Next 7 Days</TabsTrigger>
                  </TabsList>

                  <TabsContent value="24h">
                    <div className="h-64">
                      <ResponsiveContainer width="100%" height="100%">
                        <AreaChart data={forecastData.slice(0, 24)}>
                          <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                          <XAxis dataKey="time" stroke="hsl(var(--muted-foreground))" fontSize={12} />
                          <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} />
                          <Tooltip
                            contentStyle={{
                              backgroundColor: "hsl(var(--card))",
                              border: "1px solid hsl(var(--border))",
                              borderRadius: "8px",
                            }}
                          />
                          <Area
                            type="monotone"
                            dataKey="aqi"
                            stroke="hsl(var(--primary))"
                            fill="hsl(var(--primary))"
                            fillOpacity={0.3}
                          />
                        </AreaChart>
                      </ResponsiveContainer>
                    </div>
                  </TabsContent>

                  <TabsContent value="7d">
                    <div className="h-64">
                      <ResponsiveContainer width="100%" height="100%">
                        <LineChart data={forecastData.filter((_, i) => i % 24 === 0)}>
                          <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                          <XAxis dataKey="time" stroke="hsl(var(--muted-foreground))" fontSize={12} />
                          <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} />
                          <Tooltip
                            contentStyle={{
                              backgroundColor: "hsl(var(--card))",
                              border: "1px solid hsl(var(--border))",
                              borderRadius: "8px",
                            }}
                          />
                          <Line
                            type="monotone"
                            dataKey="aqi"
                            stroke="hsl(var(--accent))"
                            strokeWidth={3}
                            dot={{ fill: "hsl(var(--accent))", strokeWidth: 2, r: 4 }}
                          />
                        </LineChart>
                      </ResponsiveContainer>
                    </div>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          </div>

          {/* City Selection */}
          <Card>
            <CardHeader>
              <CardTitle>Select City</CardTitle>
              <CardDescription>Click on a city to view its air quality data</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                {cities.map((city) => {
                  const category = getAQICategory(city.aqi)
                  const isSelected = selectedCity.name === city.name
                  return (
                    <Card
                      key={city.name}
                      className={`cursor-pointer transition-all hover:scale-105 ${isSelected ? "ring-2 ring-primary" : ""}`}
                      onClick={() => handleCitySelect(city)}
                    >
                      <CardContent className="p-4 text-center">
                        <MapPin className="h-6 w-6 mx-auto mb-2 text-muted-foreground" />
                        <div className="font-semibold">{city.name}</div>
                        <div className="text-2xl font-bold my-1">{city.aqi}</div>
                        <Badge className={`${category.color} text-xs`}>{category.category}</Badge>
                      </CardContent>
                    </Card>
                  )
                })}
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Future Scope Section */}
      <section id="future" className="py-16 px-4 sm:px-6 lg:px-8 bg-card/50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Future Innovations</h2>
            <p className="text-xl text-muted-foreground text-balance max-w-3xl mx-auto">
              Exciting features and capabilities coming soon to enhance your air quality monitoring experience.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                icon: Smartphone,
                title: "Mobile Notifications",
                description: "Real-time push notifications for air quality alerts and recommendations",
                status: "Coming Q2 2025",
              },
              {
                icon: Building,
                title: "Smart City Integration",
                description: "Direct integration with city infrastructure and traffic management systems",
                status: "Coming Q3 2025",
              },
              {
                icon: Lightbulb,
                title: "Pollutant-Specific Insights",
                description: "Detailed analysis and recommendations for individual pollutant types",
                status: "Coming Q4 2025",
              },
            ].map((item, index) => (
              <Card key={index} className="group hover:scale-105 transition-all duration-300">
                <CardContent className="p-6">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                    <item.icon className="h-6 w-6 text-primary" />
                  </div>
                  <h3 className="text-xl font-semibold mb-2">{item.title}</h3>
                  <p className="text-muted-foreground mb-4">{item.description}</p>
                  <Badge variant="outline" className="text-xs">
                    {item.status}
                  </Badge>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Get Started Today</h2>
            <p className="text-xl text-muted-foreground text-balance max-w-3xl mx-auto">
              Join thousands of users who are already using BREATHESAFE to protect their health and plan their
              activities.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Newsletter Signup */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Bell className="h-5 w-5" />
                  Get Air Quality Alerts
                </CardTitle>
                <CardDescription>
                  Subscribe to receive personalized air quality alerts and weekly reports
                </CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubscribe} className="space-y-4">
                  <Input
                    type="email"
                    placeholder="Enter your email address"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                  />
                  <Button type="submit" className="w-full" disabled={isSubscribed}>
                    {isSubscribed ? (
                      <>
                        <CheckCircle className="mr-2 h-4 w-4" />
                        Subscribed!
                      </>
                    ) : (
                      <>
                        <Mail className="mr-2 h-4 w-4" />
                        Subscribe to Alerts
                      </>
                    )}
                  </Button>
                </form>
              </CardContent>
            </Card>

            {/* Contact Form */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="h-5 w-5" />
                  Enterprise & Government
                </CardTitle>
                <CardDescription>Interested in enterprise solutions or government partnerships?</CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleContactSubmit} className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <Input
                      placeholder="Your Name"
                      value={contactForm.name}
                      onChange={(e) => setContactForm((prev) => ({ ...prev, name: e.target.value }))}
                      required
                    />
                    <Input
                      placeholder="Organization"
                      value={contactForm.organization}
                      onChange={(e) => setContactForm((prev) => ({ ...prev, organization: e.target.value }))}
                      required
                    />
                  </div>
                  <Input
                    type="email"
                    placeholder="Email Address"
                    value={contactForm.email}
                    onChange={(e) => setContactForm((prev) => ({ ...prev, email: e.target.value }))}
                    required
                  />
                  <Textarea
                    placeholder="Tell us about your requirements..."
                    rows={4}
                    value={contactForm.message}
                    onChange={(e) => setContactForm((prev) => ({ ...prev, message: e.target.value }))}
                    required
                  />
                  <Button type="submit" className="w-full" disabled={isContactSubmitted}>
                    {isContactSubmitted ? (
                      <>
                        <CheckCircle className="mr-2 h-4 w-4" />
                        Message Sent!
                      </>
                    ) : (
                      <>
                        <Phone className="mr-2 h-4 w-4" />
                        Request Consultation
                      </>
                    )}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>

          {/* Trust Indicators */}
          <div className="mt-16 text-center">
            <p className="text-muted-foreground mb-8">Trusted by organizations worldwide</p>
            <div className="flex flex-wrap justify-center items-center gap-8 opacity-60">
              {[
                "Environmental Agency",
                "Smart Cities Initiative",
                "Public Health Department",
                "Research Universities",
                "Tech Companies",
              ].map((org, index) => (
                <div key={index} className="flex items-center gap-2">
                  <Star className="h-4 w-4" />
                  <span className="text-sm font-medium">{org}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-card border-t border-border py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <Leaf className="h-6 w-6 text-primary" />
                <span className="text-lg font-bold text-gradient">BREATHESAFE</span>
              </div>
              <p className="text-muted-foreground text-sm">
                AI-powered air quality forecasting for healthier communities worldwide.
              </p>
            </div>

            <div>
              <h4 className="font-semibold mb-4">Platform</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>
                  <button
                    onClick={() => scrollToSection("features")}
                    className="hover:text-foreground transition-colors"
                  >
                    Features
                  </button>
                </li>
                <li>
                  <button
                    onClick={() => scrollToSection("dashboard")}
                    className="hover:text-foreground transition-colors"
                  >
                    Dashboard
                  </button>
                </li>
                <li>
                  <button
                    onClick={() => window.open("/api/predict", "_blank")}
                    className="hover:text-foreground transition-colors"
                  >
                    API
                  </button>
                </li>
                <li>
                  <button onClick={() => scrollToSection("future")} className="hover:text-foreground transition-colors">
                    Mobile App
                  </button>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold mb-4">Company</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>
                  <button
                    onClick={() => scrollToSection("contact")}
                    className="hover:text-foreground transition-colors"
                  >
                    About
                  </button>
                </li>
                <li>
                  <button onClick={() => scrollToSection("future")} className="hover:text-foreground transition-colors">
                    Blog
                  </button>
                </li>
                <li>
                  <button
                    onClick={() => scrollToSection("contact")}
                    className="hover:text-foreground transition-colors"
                  >
                    Careers
                  </button>
                </li>
                <li>
                  <button
                    onClick={() => scrollToSection("contact")}
                    className="hover:text-foreground transition-colors"
                  >
                    Contact
                  </button>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold mb-4">Resources</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>
                  <button
                    onClick={() => window.open("/api/predict", "_blank")}
                    className="hover:text-foreground transition-colors"
                  >
                    Documentation
                  </button>
                </li>
                <li>
                  <button
                    onClick={() => scrollToSection("contact")}
                    className="hover:text-foreground transition-colors"
                  >
                    Help Center
                  </button>
                </li>
                <li>
                  <button
                    onClick={() => scrollToSection("contact")}
                    className="hover:text-foreground transition-colors"
                  >
                    Privacy Policy
                  </button>
                </li>
                <li>
                  <button
                    onClick={() => scrollToSection("contact")}
                    className="hover:text-foreground transition-colors"
                  >
                    Terms of Service
                  </button>
                </li>
              </ul>
            </div>
          </div>

          <div className="border-t border-border mt-8 pt-8 text-center text-sm text-muted-foreground">
            <p>&copy; 2025 BREATHESAFE. All rights reserved. Predict today, breathe better tomorrow.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
