import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import { Analytics } from "@vercel/analytics/next"
import "./globals.css"
import { Suspense } from "react"

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-sans",
  display: "swap",
})

export const metadata: Metadata = {
  title: "BREATHESAFE - AI-Powered Air Quality Forecasting Platform",
  description:
    "Predict today, breathe better tomorrow. Advanced AI-powered air quality monitoring and forecasting for healthier communities.",
  generator: "v0.app",
  keywords: ["air quality", "AQI", "pollution", "forecasting", "AI", "machine learning", "health", "environment"],
  authors: [{ name: "BREATHESAFE Team" }],
  openGraph: {
    title: "BREATHESAFE - AI-Powered Air Quality Forecasting",
    description: "Predict today, breathe better tomorrow. Advanced AI-powered air quality monitoring and forecasting.",
    type: "website",
  },
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className="dark">
      <body className={`${inter.variable} font-sans antialiased`}>
        <Suspense>
          {children}
          <Analytics />
        </Suspense>
      </body>
    </html>
  )
}
