import { type NextRequest, NextResponse } from "next/server"

// Mock prediction function
function predictAQI(data: any) {
  // Simulate ML model prediction
  const baseAQI = Math.random() * 200 + 50
  const variation = (Math.random() - 0.5) * 40

  return {
    predicted_aqi: Math.max(0, Math.min(500, Math.round(baseAQI + variation))),
    confidence: Math.random() * 30 + 70,
    model_used: "Random Forest",
    timestamp: new Date().toISOString(),
  }
}

export async function POST(request: NextRequest) {
  try {
    const data = await request.json()

    // Validate input data
    const requiredFields = [
      "pm25",
      "pm10",
      "no2",
      "so2",
      "co",
      "o3",
      "temperature",
      "humidity",
      "wind_speed",
      "pressure",
    ]
    const missingFields = requiredFields.filter((field) => !(field in data))

    if (missingFields.length > 0) {
      return NextResponse.json({ error: `Missing required fields: ${missingFields.join(", ")}` }, { status: 400 })
    }

    // Generate prediction
    const prediction = predictAQI(data)

    return NextResponse.json({
      success: true,
      prediction,
      input_data: data,
    })
  } catch (error) {
    return NextResponse.json({ error: "Invalid request data" }, { status: 400 })
  }
}

export async function GET() {
  return NextResponse.json({
    message: "AQI Prediction API",
    version: "1.0.0",
    endpoints: {
      "POST /api/predict": "Predict AQI based on pollutant and weather data",
    },
    required_fields: ["pm25", "pm10", "no2", "so2", "co", "o3", "temperature", "humidity", "wind_speed", "pressure"],
  })
}
