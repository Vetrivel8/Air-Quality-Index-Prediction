import streamlit as st
import pandas as pd
import numpy as np
import plotly.graph_objects as go
import plotly.express as px
from datetime import datetime, timedelta
import sys
import os

# Add scripts directory to path
sys.path.append('scripts')

from scripts.data_preprocessing import AQIDataPreprocessor
from scripts.forecasting_engine import AQIForecaster

# Page configuration
st.set_page_config(
    page_title="AQI Prediction Dashboard",
    page_icon="🌬️",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS
st.markdown("""
<style>
    .main-header {
        font-size: 3rem;
        font-weight: bold;
        text-align: center;
        margin-bottom: 2rem;
        background: linear-gradient(90deg, #1f77b4, #ff7f0e);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
    }
    
    .metric-card {
        background: white;
        padding: 1rem;
        border-radius: 10px;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        border-left: 4px solid #1f77b4;
    }
    
    .aqi-good { background-color: #00E400; color: white; }
    .aqi-moderate { background-color: #FFFF00; color: black; }
    .aqi-poor { background-color: #FF7E00; color: white; }
    .aqi-very-poor { background-color: #FF0000; color: white; }
    .aqi-severe { background-color: #8F3F97; color: white; }
    
    .forecast-card {
        padding: 1rem;
        border-radius: 8px;
        margin: 0.5rem 0;
        text-align: center;
        font-weight: bold;
    }
</style>
""", unsafe_allow_html=True)

@st.cache_data
def load_data():
    """Load and cache the dataset"""
    try:
        df = pd.read_csv('aqi_processed.csv')
        df['datetime'] = pd.to_datetime(df['datetime'])
        return df.sort_values('datetime')
    except FileNotFoundError:
        st.error("Dataset not found. Please run the data generation script first.")
        return None

@st.cache_resource
def load_forecaster():
    """Load and cache the forecaster"""
    forecaster = AQIForecaster()
    forecaster.load_models()
    return forecaster

def get_aqi_color(aqi_value):
    """Get color for AQI value"""
    if aqi_value <= 50:
        return '#00E400'
    elif aqi_value <= 100:
        return '#FFFF00'
    elif aqi_value <= 200:
        return '#FF7E00'
    elif aqi_value <= 300:
        return '#FF0000'
    else:
        return '#8F3F97'

def get_aqi_category(aqi_value):
    """Get AQI category"""
    if aqi_value <= 50:
        return 'Good'
    elif aqi_value <= 100:
        return 'Moderate'
    elif aqi_value <= 200:
        return 'Poor'
    elif aqi_value <= 300:
        return 'Very Poor'
    else:
        return 'Severe'

def create_gauge_chart(aqi_value, title="Current AQI"):
    """Create AQI gauge chart"""
    fig = go.Figure(go.Indicator(
        mode = "gauge+number+delta",
        value = aqi_value,
        domain = {'x': [0, 1], 'y': [0, 1]},
        title = {'text': title, 'font': {'size': 24}},
        delta = {'reference': 100},
        gauge = {
            'axis': {'range': [None, 500], 'tickwidth': 1, 'tickcolor': "darkblue"},
            'bar': {'color': get_aqi_color(aqi_value)},
            'bgcolor': "white",
            'borderwidth': 2,
            'bordercolor': "gray",
            'steps': [
                {'range': [0, 50], 'color': '#00E400'},
                {'range': [50, 100], 'color': '#FFFF00'},
                {'range': [100, 200], 'color': '#FF7E00'},
                {'range': [200, 300], 'color': '#FF0000'},
                {'range': [300, 500], 'color': '#8F3F97'}
            ],
            'threshold': {
                'line': {'color': "red", 'width': 4},
                'thickness': 0.75,
                'value': aqi_value
            }
        }
    ))
    
    fig.update_layout(height=300, margin=dict(l=20, r=20, t=40, b=20))
    return fig

def create_time_series_plot(df, columns, title="Time Series"):
    """Create time series plot"""
    fig = go.Figure()
    
    for col in columns:
        fig.add_trace(go.Scatter(
            x=df['datetime'],
            y=df[col],
            mode='lines',
            name=col.upper(),
            line=dict(width=2)
        ))
    
    fig.update_layout(
        title=title,
        xaxis_title="Date",
        yaxis_title="Value",
        height=400,
        hovermode='x unified'
    )
    
    return fig

def create_correlation_heatmap(df):
    """Create correlation heatmap"""
    # Select numeric columns
    numeric_cols = ['temperature', 'humidity', 'wind_speed', 'pressure', 'rainfall',
                   'pm25', 'pm10', 'no2', 'so2', 'co', 'o3', 'aqi']
    
    corr_matrix = df[numeric_cols].corr()
    
    fig = px.imshow(
        corr_matrix,
        text_auto=True,
        aspect="auto",
        title="Feature Correlation Matrix",
        color_continuous_scale="RdBu_r"
    )
    
    fig.update_layout(height=600)
    return fig

def create_forecast_plot(forecasts):
    """Create forecast visualization"""
    fig = go.Figure()
    
    for model_name, model_forecasts in forecasts.items():
        if not model_forecasts:
            continue
            
        times = [f['datetime'] for f in model_forecasts]
        aqi_values = [f['predicted_aqi'] for f in model_forecasts]
        
        fig.add_trace(go.Scatter(
            x=times,
            y=aqi_values,
            mode='lines+markers',
            name=f'{model_name} Forecast',
            line=dict(width=3),
            marker=dict(size=6)
        ))
    
    fig.update_layout(
        title="24-Hour AQI Forecast",
        xaxis_title="Time",
        yaxis_title="Predicted AQI",
        height=400,
        hovermode='x unified'
    )
    
    return fig

def main():
    # Header
    st.markdown('<h1 class="main-header">🌬️ AQI Prediction Dashboard</h1>', unsafe_allow_html=True)
    
    # Load data
    df = load_data()
    if df is None:
        st.stop()
    
    # Sidebar
    st.sidebar.header("Dashboard Controls")
    
    # Date range selector
    min_date = df['datetime'].min().date()
    max_date = df['datetime'].max().date()
    
    date_range = st.sidebar.date_input(
        "Select Date Range",
        value=(max_date - timedelta(days=7), max_date),
        min_value=min_date,
        max_value=max_date
    )
    
    # Filter data
    if len(date_range) == 2:
        start_date, end_date = date_range
        filtered_df = df[
            (df['datetime'].dt.date >= start_date) & 
            (df['datetime'].dt.date <= end_date)
        ]
    else:
        filtered_df = df
    
    # Current AQI Section
    st.header("📊 Current Air Quality Status")
    
    current_aqi = filtered_df['aqi'].iloc[-1]
    current_category = get_aqi_category(current_aqi)
    
    col1, col2, col3 = st.columns([2, 1, 1])
    
    with col1:
        # AQI Gauge
        gauge_fig = create_gauge_chart(current_aqi, "Current AQI")
        st.plotly_chart(gauge_fig, use_container_width=True)
    
    with col2:
        st.metric("AQI Value", f"{current_aqi:.0f}")
        st.metric("Category", current_category)
        
        # Health recommendations
        forecaster = load_forecaster()
        if forecaster.models_loaded:
            recommendations = forecaster.get_health_recommendations(current_category)
            st.subheader("Health Recommendations")
            for rec in recommendations:
                st.write(f"• {rec}")
    
    with col3:
        # Current pollutant levels
        st.subheader("Current Levels")
        latest_data = filtered_df.iloc[-1]
        
        st.metric("PM2.5", f"{latest_data['pm25']:.1f} μg/m³")
        st.metric("PM10", f"{latest_data['pm10']:.1f} μg/m³")
        st.metric("NO₂", f"{latest_data['no2']:.1f} μg/m³")
        st.metric("O₃", f"{latest_data['o3']:.1f} μg/m³")
    
    # Forecast Section
    st.header("🔮 24-Hour AQI Forecast")
    
    if st.button("Generate Forecast", type="primary"):
        with st.spinner("Generating forecast..."):
            forecaster = load_forecaster()
            
            if forecaster.models_loaded:
                # Use last 48 hours for forecasting
                recent_data = df.tail(48).copy()
                forecasts = forecaster.forecast_aqi(recent_data, hours_ahead=24)
                
                if forecasts:
                    # Forecast plot
                    forecast_fig = create_forecast_plot(forecasts)
                    st.plotly_chart(forecast_fig, use_container_width=True)
                    
                    # Forecast summary
                    summary = forecaster.create_forecast_summary(forecasts)
                    
                    st.subheader("Forecast Summary")
                    cols = st.columns(len(summary))
                    
                    for i, (model_name, model_summary) in enumerate(summary.items()):
                        with cols[i]:
                            st.write(f"**{model_name}**")
                            st.metric("Avg AQI", f"{model_summary['avg_aqi']}")
                            st.metric("Max AQI", f"{model_summary['max_aqi']}")
                            st.write(f"**Dominant:** {model_summary['dominant_category']}")
                    
                    # Detailed hourly forecast
                    st.subheader("Hourly Forecast Details")
                    
                    for model_name, model_forecasts in forecasts.items():
                        if not model_forecasts:
                            continue
                            
                        st.write(f"**{model_name} Model**")
                        
                        # Create columns for hourly display
                        hours_per_row = 6
                        for i in range(0, min(24, len(model_forecasts)), hours_per_row):
                            cols = st.columns(hours_per_row)
                            
                            for j in range(hours_per_row):
                                if i + j < len(model_forecasts):
                                    forecast = model_forecasts[i + j]
                                    hour = forecast['datetime'].strftime('%H:%M')
                                    aqi = forecast['predicted_aqi']
                                    category = forecast['category']
                                    
                                    with cols[j]:
                                        st.markdown(f"""
                                        <div class="forecast-card" style="background-color: {forecast['color']}; color: {'white' if category != 'Moderate' else 'black'};">
                                            <div>{hour}</div>
                                            <div>AQI {aqi}</div>
                                            <div>{category}</div>
                                        </div>
                                        """, unsafe_allow_html=True)
                        
                        st.write("---")
                
                else:
                    st.error("Failed to generate forecasts. Please check if models are trained.")
            else:
                st.error("Models not loaded. Please train the models first.")
    
    # Historical Data Analysis
    st.header("📈 Historical Data Analysis")
    
    # Time series plots
    tab1, tab2, tab3 = st.tabs(["AQI Trends", "Pollutants", "Weather"])
    
    with tab1:
        aqi_fig = create_time_series_plot(filtered_df, ['aqi'], "AQI Over Time")
        st.plotly_chart(aqi_fig, use_container_width=True)
        
        # AQI statistics
        col1, col2, col3, col4 = st.columns(4)
        with col1:
            st.metric("Average AQI", f"{filtered_df['aqi'].mean():.1f}")
        with col2:
            st.metric("Max AQI", f"{filtered_df['aqi'].max():.1f}")
        with col3:
            st.metric("Min AQI", f"{filtered_df['aqi'].min():.1f}")
        with col4:
            st.metric("Std Dev", f"{filtered_df['aqi'].std():.1f}")
    
    with tab2:
        pollutant_cols = ['pm25', 'pm10', 'no2', 'so2', 'co', 'o3']
        pollutant_fig = create_time_series_plot(filtered_df, pollutant_cols, "Pollutant Levels")
        st.plotly_chart(pollutant_fig, use_container_width=True)
        
        # Pollutant statistics
        st.subheader("Pollutant Statistics")
        stats_df = filtered_df[pollutant_cols].describe().round(2)
        st.dataframe(stats_df)
    
    with tab3:
        weather_cols = ['temperature', 'humidity', 'wind_speed', 'pressure']
        weather_fig = create_time_series_plot(filtered_df, weather_cols, "Weather Parameters")
        st.plotly_chart(weather_fig, use_container_width=True)
    
    # Correlation Analysis
    st.header("🔗 Feature Correlation Analysis")
    corr_fig = create_correlation_heatmap(filtered_df)
    st.plotly_chart(corr_fig, use_container_width=True)
    
    # Data Quality Section
    st.header("📋 Data Quality Report")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("Missing Values")
        missing_data = filtered_df.isnull().sum()
        missing_df = pd.DataFrame({
            'Column': missing_data.index,
            'Missing Count': missing_data.values,
            'Missing %': (missing_data.values / len(filtered_df) * 100).round(2)
        })
        st.dataframe(missing_df[missing_df['Missing Count'] > 0])
    
    with col2:
        st.subheader("Dataset Info")
        st.write(f"**Total Records:** {len(filtered_df):,}")
        st.write(f"**Date Range:** {filtered_df['datetime'].min().strftime('%Y-%m-%d')} to {filtered_df['datetime'].max().strftime('%Y-%m-%d')}")
        st.write(f"**Features:** {len(filtered_df.columns)}")
        
        # AQI category distribution
        category_counts = filtered_df['aqi_category'].value_counts()
        st.subheader("AQI Category Distribution")
        for category, count in category_counts.items():
            percentage = (count / len(filtered_df)) * 100
            st.write(f"**{category}:** {count} ({percentage:.1f}%)")
    
    # Footer
    st.markdown("---")
    st.markdown("""
    <div style='text-align: center; color: gray;'>
        <p>AQI Prediction Dashboard | Built with Streamlit & Machine Learning</p>
        <p>Data updates every hour | Forecasts generated using Random Forest & LSTM models</p>
    </div>
    """, unsafe_allow_html=True)

if __name__ == "__main__":
    main()
