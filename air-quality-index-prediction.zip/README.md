# AQI Prediction System

A comprehensive machine learning system for predicting Air Quality Index (AQI) using historical air quality and weather data. The system includes Random Forest and LSTM models, a Streamlit dashboard, and a FastAPI server.

## Features

- **Synthetic Dataset Generation**: Creates realistic AQI data with proper correlations
- **Data Preprocessing**: Handles missing values, feature engineering, and scaling
- **Multiple Models**: Random Forest and LSTM for different prediction approaches
- **Model Evaluation**: Comprehensive metrics and visualizations
- **24-Hour Forecasting**: Predict AQI for the next 24 hours
- **AQI Categorization**: Classify predictions into standard AQI categories
- **Health Recommendations**: Provide health advice based on AQI levels
- **Interactive Dashboard**: Streamlit web interface
- **REST API**: FastAPI server for integration

## Installation

1. Install required packages:
\`\`\`bash
pip install -r requirements.txt
\`\`\`

2. For the API server, also install:
\`\`\`bash
pip install fastapi uvicorn
\`\`\`

## Quick Start

### Option 1: Run Complete Pipeline
\`\`\`bash
python run_complete_pipeline.py
\`\`\`

This will:
1. Generate synthetic dataset
2. Preprocess the data
3. Train both models
4. Evaluate performance
5. Test forecasting

### Option 2: Run Individual Steps

1. **Generate Dataset**:
\`\`\`bash
python scripts/01_generate_dataset.py
\`\`\`

2. **Preprocess Data**:
\`\`\`bash
python scripts/02_data_preprocessing.py
\`\`\`

3. **Train Models**:
\`\`\`bash
python scripts/03_train_random_forest.py
python scripts/04_train_lstm.py
\`\`\`

4. **Evaluate Models**:
\`\`\`bash
python scripts/05_model_evaluation.py
\`\`\`

5. **Test Forecasting**:
\`\`\`bash
python scripts/06_forecasting_engine.py
\`\`\`

## Usage

### Streamlit Dashboard
\`\`\`bash
streamlit run streamlit_app.py
\`\`\`

Features:
- Real-time AQI monitoring
- 24-hour forecasting
- Historical data analysis
- Interactive visualizations
- Health recommendations

### FastAPI Server
\`\`\`bash
uvicorn api_server:app --reload
\`\`\`

API Endpoints:
- `POST /predict`: Predict AQI from current conditions
- `POST /forecast`: Generate 24-hour forecast
- `GET /health/{aqi_value}`: Get health recommendations
- `GET /status`: Check API status

### Python Integration

\`\`\`python
from scripts.forecasting_engine import AQIForecaster
import pandas as pd

# Load forecaster
forecaster = AQIForecaster()
forecaster.load_models()

# Prepare current data
current_data = pd.DataFrame({
    'datetime': ['2024-01-01 12:00:00'],
    'temperature': [25.0],
    'humidity': [60.0],
    'wind_speed': [5.0],
    'pressure': [1013.0],
    'rainfall': [0.0],
    'pm25': [35.0],
    'pm10': [50.0],
    'no2': [25.0],
    'so2': [10.0],
    'co': [1.0],
    'o3': [80.0]
})

# Generate forecast
forecasts = forecaster.forecast_aqi(current_data, hours_ahead=24)
\`\`\`

## Dataset Features

### Weather Parameters
- Temperature (°C)
- Humidity (%)
- Wind Speed (m/s)
- Atmospheric Pressure (hPa)
- Rainfall (mm)

### Pollutants
- PM2.5 (μg/m³)
- PM10 (μg/m³)
- NO₂ (μg/m³)
- SO₂ (μg/m³)
- CO (mg/m³)
- O₃ (μg/m³)

### Target
- AQI (0-500 scale)
- AQI Category (Good, Moderate, Poor, Very Poor, Severe)

## Model Performance

The system includes two complementary models:

### Random Forest
- **Strengths**: Fast inference, feature importance, handles non-linear relationships
- **Use Case**: Real-time predictions, feature analysis

### LSTM
- **Strengths**: Captures temporal patterns, sequence modeling
- **Use Case**: Time series forecasting, trend analysis

## AQI Categories

| AQI Range | Category | Color | Health Impact |
|-----------|----------|-------|---------------|
| 0-50 | Good | Green | Minimal impact |
| 51-100 | Moderate | Yellow | Acceptable for most people |
| 101-200 | Poor | Orange | Sensitive groups affected |
| 201-300 | Very Poor | Red | Everyone affected |
| 301-500 | Severe | Purple | Health emergency |

## File Structure

\`\`\`
aqi-prediction-system/
├── scripts/
│   ├── 01_generate_dataset.py      # Dataset generation
│   ├── 02_data_preprocessing.py    # Data preprocessing
│   ├── 03_train_random_forest.py   # Random Forest training
│   ├── 04_train_lstm.py            # LSTM training
│   ├── 05_model_evaluation.py      # Model evaluation
│   └── 06_forecasting_engine.py    # Forecasting engine
├── streamlit_app.py                # Streamlit dashboard
├── api_server.py                   # FastAPI server
├── run_complete_pipeline.py        # Complete pipeline runner
├── requirements.txt                # Python dependencies
└── README.md                       # This file
\`\`\`

## Generated Files

After running the pipeline:
- `aqi_dataset.csv`: Raw synthetic dataset
- `aqi_processed.csv`: Preprocessed dataset
- `preprocessor.joblib`: Fitted preprocessor
- `random_forest_model.joblib`: Trained Random Forest model
- `lstm_model.h5`: Trained LSTM model
- `lstm_model_metadata.joblib`: LSTM metadata
- Various visualization plots (PNG files)
- `evaluation_report.txt`: Model comparison report

## Customization

### Adding Real Data
Replace the synthetic dataset generation with real data loading:

\`\`\`python
# In scripts/01_generate_dataset.py
def load_real_data():
    # Load your real AQI and weather data
    df = pd.read_csv('your_real_data.csv')
    return df
\`\`\`

### Model Tuning
Modify hyperparameters in the training scripts:

\`\`\`python
# In scripts/03_train_random_forest.py
param_grid = {
    'n_estimators': [100, 200, 500],
    'max_depth': [10, 20, None],
    # Add more parameters
}
\`\`\`

### Adding Features
Extend the preprocessing pipeline:

\`\`\`python
# In scripts/02_data_preprocessing.py
def create_custom_features(self, df):
    # Add your custom features
    df['custom_feature'] = df['pm25'] / df['wind_speed']
    return df
\`\`\`

## Deployment

### Docker Deployment
Create a Dockerfile:

\`\`\`dockerfile
FROM python:3.9-slim

WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt

COPY . .

EXPOSE 8000
CMD ["uvicorn", "api_server:app", "--host", "0.0.0.0", "--port", "8000"]
\`\`\`

### Cloud Deployment
- **Streamlit Cloud**: Deploy the dashboard directly
- **Heroku**: Deploy the FastAPI server
- **AWS/GCP**: Use container services for scalable deployment

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## License

This project is open source and available under the MIT License.

## Support

For issues and questions:
1. Check the troubleshooting section
2. Review the generated evaluation reports
3. Examine the log outputs from the pipeline

## Troubleshooting

### Common Issues

1. **Models not loading**: Ensure all training scripts completed successfully
2. **Memory errors**: Reduce dataset size or batch size for LSTM
3. **Import errors**: Check that all dependencies are installed
4. **Prediction errors**: Verify input data format matches training data

### Performance Tips

1. **For faster training**: Reduce dataset size or use fewer features
2. **For better accuracy**: Increase model complexity or add more features
3. **For real-time use**: Use Random Forest model for faster inference
