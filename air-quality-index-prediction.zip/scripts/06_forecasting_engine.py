import pandas as pd
import numpy as np
import joblib
import tensorflow as tf
from datetime import datetime, timedelta
import warnings
warnings.filterwarnings('ignore')

class AQIForecaster:
    def __init__(self):
        self.rf_model = None
        self.lstm_model = None
        self.preprocessor = None
        self.models_loaded = False
        
    def load_models(self):
        """Load all trained models and preprocessor"""
        try:
            # Load preprocessor
            preprocessor_data = joblib.load('preprocessor.joblib')
            self.preprocessor = {
                'scaler': preprocessor_data['scaler'],
                'imputer': preprocessor_data['imputer'],
                'feature_columns': preprocessor_data['feature_columns']
            }
            print("✓ Preprocessor loaded")
            
            # Load Random Forest
            rf_data = joblib.load('random_forest_model.joblib')
            self.rf_model = {
                'model': rf_data['model'],
                'feature_columns': rf_data['feature_columns']
            }
            print("✓ Random Forest model loaded")
            
            # Load LSTM
            lstm_model = tf.keras.models.load_model('lstm_model.h5')
            lstm_metadata = joblib.load('lstm_model_metadata.joblib')
            
            self.lstm_model = {
                'model': lstm_model,
                'scaler_X': lstm_metadata['scaler_X'],
                'scaler_y': lstm_metadata['scaler_y'],
                'sequence_length': lstm_metadata['sequence_length'],
                'feature_columns': lstm_metadata['feature_columns']
            }
            print("✓ LSTM model loaded")
            
            self.models_loaded = True
            
        except Exception as e:
            print(f"Error loading models: {e}")
            self.models_loaded = False
    
    def categorize_aqi(self, aqi_value):
        """Categorize single AQI value"""
        if aqi_value <= 50:
            return 'Good', '#00E400'  # Green
        elif aqi_value <= 100:
            return 'Moderate', '#FFFF00'  # Yellow
        elif aqi_value <= 200:
            return 'Poor', '#FF7E00'  # Orange
        elif aqi_value <= 300:
            return 'Very Poor', '#FF0000'  # Red
        else:
            return 'Severe', '#8F3F97'  # Purple
    
    def get_health_recommendations(self, aqi_category):
        """Get health recommendations based on AQI category"""
        recommendations = {
            'Good': [
                "Air quality is satisfactory",
                "Ideal for outdoor activities",
                "No health precautions needed"
            ],
            'Moderate': [
                "Air quality is acceptable for most people",
                "Unusually sensitive people should consider reducing outdoor activities",
                "Generally safe for outdoor exercise"
            ],
            'Poor': [
                "Sensitive groups should reduce outdoor activities",
                "Everyone should limit prolonged outdoor exertion",
                "Consider wearing a mask outdoors"
            ],
            'Very Poor': [
                "Everyone should avoid outdoor activities",
                "Sensitive groups should stay indoors",
                "Wear N95 masks if you must go outside"
            ],
            'Severe': [
                "Health emergency - everyone should avoid outdoor activities",
                "Stay indoors with air purifiers if possible",
                "Seek medical attention if experiencing symptoms"
            ]
        }
        return recommendations.get(aqi_category, [])
    
    def create_time_features(self, df):
        """Create time-based features for forecasting"""
        df = df.copy()
        df['hour'] = df['datetime'].dt.hour
        df['day_of_week'] = df['datetime'].dt.dayofweek
        df['month'] = df['datetime'].dt.month
        df['day_of_year'] = df['datetime'].dt.dayofyear
        
        # Cyclical encoding
        df['hour_sin'] = np.sin(2 * np.pi * df['hour'] / 24)
        df['hour_cos'] = np.cos(2 * np.pi * df['hour'] / 24)
        df['day_sin'] = np.sin(2 * np.pi * df['day_of_week'] / 7)
        df['day_cos'] = np.cos(2 * np.pi * df['day_of_week'] / 7)
        df['month_sin'] = np.sin(2 * np.pi * df['month'] / 12)
        df['month_cos'] = np.cos(2 * np.pi * df['month'] / 12)
        
        return df
    
    def forecast_weather_simple(self, last_weather, hours_ahead):
        """Simple weather forecasting (in real app, use weather API)"""
        forecasted_weather = []
        
        for h in range(hours_ahead):
            # Simple persistence with small random variations
            forecast = {}
            for col in ['temperature', 'humidity', 'wind_speed', 'pressure', 'rainfall']:
                if col == 'rainfall':
                    # Random rainfall events
                    forecast[col] = np.random.exponential(0.5) if np.random.random() < 0.1 else 0
                else:
                    # Add small random variations to last known values
                    base_value = last_weather[col]
                    variation = np.random.normal(0, 0.1) * base_value
                    forecast[col] = max(0, base_value + variation)
            
            forecasted_weather.append(forecast)
        
        return forecasted_weather
    
    def forecast_aqi_rf(self, current_data, hours_ahead=24):
        """Forecast AQI using Random Forest model"""
        if not self.models_loaded or self.rf_model is None:
            raise ValueError("Random Forest model not loaded")
        
        forecasts = []
        current_df = current_data.copy()
        
        for hour in range(hours_ahead):
            # Create future timestamp
            future_time = current_df['datetime'].iloc[-1] + timedelta(hours=hour+1)
            
            # Get weather forecast (simplified)
            last_weather = current_df[['temperature', 'humidity', 'wind_speed', 'pressure', 'rainfall']].iloc[-1]
            weather_forecast = self.forecast_weather_simple(last_weather, 1)[0]
            
            # Create future row
            future_row = pd.DataFrame({
                'datetime': [future_time],
                'temperature': [weather_forecast['temperature']],
                'humidity': [weather_forecast['humidity']],
                'wind_speed': [weather_forecast['wind_speed']],
                'pressure': [weather_forecast['pressure']],
                'rainfall': [weather_forecast['rainfall']],
                # Use last known pollutant values (in real app, these would be forecasted too)
                'pm25': [current_df['pm25'].iloc[-1]],
                'pm10': [current_df['pm10'].iloc[-1]],
                'no2': [current_df['no2'].iloc[-1]],
                'so2': [current_df['so2'].iloc[-1]],
                'co': [current_df['co'].iloc[-1]],
                'o3': [current_df['o3'].iloc[-1]]
            })
            
            # Add time features
            future_row = self.create_time_features(future_row)
            
            # Create lag features (simplified - use recent values)
            for col in ['pm25', 'pm10', 'no2', 'so2', 'co', 'o3', 'temperature', 'humidity', 'wind_speed']:
                for lag in [1, 3, 6, 12, 24]:
                    if len(current_df) >= lag:
                        future_row[f'{col}_lag_{lag}h'] = current_df[col].iloc[-lag]
                    else:
                        future_row[f'{col}_lag_{lag}h'] = current_df[col].iloc[-1]
            
            # Create rolling averages
            for col in ['pm25', 'pm10', 'no2', 'so2', 'co', 'o3']:
                future_row[f'{col}_rolling_3h'] = current_df[col].tail(3).mean()
                future_row[f'{col}_rolling_6h'] = current_df[col].tail(6).mean()
                future_row[f'{col}_rolling_24h'] = current_df[col].tail(24).mean()
            
            # Create interaction features
            future_row['temp_humidity'] = future_row['temperature'] * future_row['humidity']
            future_row['wind_rainfall'] = future_row['wind_speed'] * future_row['rainfall']
            future_row['pm25_pm10_ratio'] = future_row['pm25'] / (future_row['pm10'] + 1e-6)
            future_row['no2_o3_ratio'] = future_row['no2'] / (future_row['o3'] + 1e-6)
            
            # Select features for prediction
            feature_cols = self.rf_model['feature_columns']
            X_future = future_row[feature_cols]
            
            # Handle missing features
            for col in feature_cols:
                if col not in X_future.columns:
                    X_future[col] = 0
            
            # Make prediction
            aqi_pred = self.rf_model['model'].predict(X_future)[0]
            category, color = self.categorize_aqi(aqi_pred)
            
            forecast = {
                'datetime': future_time,
                'predicted_aqi': round(aqi_pred, 1),
                'category': category,
                'color': color,
                'model': 'Random Forest'
            }
            
            forecasts.append(forecast)
            
            # Add prediction to current_df for next iteration
            future_row['aqi'] = aqi_pred
            current_df = pd.concat([current_df, future_row], ignore_index=True)
        
        return forecasts
    
    def forecast_aqi_lstm(self, current_data, hours_ahead=24):
        """Forecast AQI using LSTM model"""
        if not self.models_loaded or self.lstm_model is None:
            raise ValueError("LSTM model not loaded")
        
        forecasts = []
        seq_length = self.lstm_model['sequence_length']
        
        if len(current_data) < seq_length:
            raise ValueError(f"Need at least {seq_length} hours of data for LSTM forecasting")
        
        # Prepare initial sequence
        feature_cols = self.lstm_model['feature_columns']
        current_sequence = current_data[feature_cols].tail(seq_length).values
        
        for hour in range(hours_ahead):
            # Scale the sequence
            sequence_scaled = self.lstm_model['scaler_X'].transform(current_sequence)
            sequence_input = sequence_scaled.reshape(1, seq_length, -1)
            
            # Make prediction
            aqi_pred_scaled = self.lstm_model['model'].predict(sequence_input, verbose=0)
            aqi_pred = self.lstm_model['scaler_y'].inverse_transform(aqi_pred_scaled)[0][0]
            
            # Create future timestamp
            future_time = current_data['datetime'].iloc[-1] + timedelta(hours=hour+1)
            category, color = self.categorize_aqi(aqi_pred)
            
            forecast = {
                'datetime': future_time,
                'predicted_aqi': round(aqi_pred, 1),
                'category': category,
                'color': color,
                'model': 'LSTM'
            }
            
            forecasts.append(forecast)
            
            # Update sequence for next prediction (simplified)
            # In practice, you'd need to forecast all features
            last_row = current_sequence[-1].copy()
            # Update with predicted AQI and some variations
            new_row = last_row * (1 + np.random.normal(0, 0.05, len(last_row)))
            current_sequence = np.vstack([current_sequence[1:], new_row])
        
        return forecasts
    
    def forecast_aqi(self, current_data, hours_ahead=24, model='both'):
        """Main forecasting function"""
        if not self.models_loaded:
            self.load_models()
        
        results = {}
        
        if model in ['rf', 'both']:
            try:
                rf_forecasts = self.forecast_aqi_rf(current_data, hours_ahead)
                results['Random Forest'] = rf_forecasts
            except Exception as e:
                print(f"Random Forest forecasting failed: {e}")
        
        if model in ['lstm', 'both']:
            try:
                lstm_forecasts = self.forecast_aqi_lstm(current_data, hours_ahead)
                results['LSTM'] = lstm_forecasts
            except Exception as e:
                print(f"LSTM forecasting failed: {e}")
        
        return results
    
    def create_forecast_summary(self, forecasts):
        """Create a summary of forecasts"""
        summary = {}
        
        for model_name, model_forecasts in forecasts.items():
            if not model_forecasts:
                continue
                
            aqi_values = [f['predicted_aqi'] for f in model_forecasts]
            categories = [f['category'] for f in model_forecasts]
            
            summary[model_name] = {
                'avg_aqi': round(np.mean(aqi_values), 1),
                'max_aqi': round(np.max(aqi_values), 1),
                'min_aqi': round(np.min(aqi_values), 1),
                'dominant_category': max(set(categories), key=categories.count),
                'category_distribution': {cat: categories.count(cat) for cat in set(categories)}
            }
        
        return summary

# Example usage and testing
if __name__ == "__main__":
    # Initialize forecaster
    forecaster = AQIForecaster()
    
    # Load models
    forecaster.load_models()
    
    if forecaster.models_loaded:
        # Load recent data for forecasting
        df = pd.read_csv('aqi_processed.csv')
        df['datetime'] = pd.to_datetime(df['datetime'])
        df = df.sort_values('datetime')
        
        # Use last 48 hours of data
        recent_data = df.tail(48).copy()
        
        print("Making 24-hour AQI forecast...")
        forecasts = forecaster.forecast_aqi(recent_data, hours_ahead=24)
        
        # Display results
        for model_name, model_forecasts in forecasts.items():
            print(f"\n--- {model_name} Forecast ---")
            for i, forecast in enumerate(model_forecasts[:6]):  # Show first 6 hours
                print(f"Hour {i+1}: AQI {forecast['predicted_aqi']} ({forecast['category']})")
        
        # Create summary
        summary = forecaster.create_forecast_summary(forecasts)
        print("\n--- Forecast Summary ---")
        for model_name, model_summary in summary.items():
            print(f"{model_name}:")
            print(f"  Average AQI: {model_summary['avg_aqi']}")
            print(f"  Max AQI: {model_summary['max_aqi']}")
            print(f"  Dominant Category: {model_summary['dominant_category']}")
        
        print("\n✓ Forecasting engine test completed!")
    else:
        print("Models not loaded. Please train models first.")
