import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import random

# Set random seed for reproducibility
np.random.seed(42)
random.seed(42)

def generate_aqi_dataset(days=730):  # 2 years of data
    """Generate synthetic AQI dataset with realistic correlations"""
    
    # Create date range
    start_date = datetime.now() - timedelta(days=days)
    dates = pd.date_range(start=start_date, periods=days*24, freq='H')
    
    n_samples = len(dates)
    
    # Generate base weather patterns with seasonal variations
    day_of_year = np.array([d.timetuple().tm_yday for d in dates])
    hour_of_day = np.array([d.hour for d in dates])
    
    # Temperature with seasonal and daily patterns
    temp_seasonal = 15 + 10 * np.sin(2 * np.pi * day_of_year / 365)
    temp_daily = 5 * np.sin(2 * np.pi * hour_of_day / 24)
    temperature = temp_seasonal + temp_daily + np.random.normal(0, 3, n_samples)
    temperature = np.clip(temperature, -5, 40)
    
    # Humidity (inversely related to temperature)
    humidity = 70 - 0.5 * temperature + np.random.normal(0, 10, n_samples)
    humidity = np.clip(humidity, 20, 95)
    
    # Wind speed (affects pollutant dispersion)
    wind_speed = 5 + 3 * np.sin(2 * np.pi * day_of_year / 365) + np.random.exponential(2, n_samples)
    wind_speed = np.clip(wind_speed, 0, 25)
    
    # Pressure
    pressure = 1013 + 10 * np.sin(2 * np.pi * day_of_year / 365) + np.random.normal(0, 5, n_samples)
    
    # Rainfall (seasonal pattern)
    rainfall_prob = 0.1 + 0.05 * np.sin(2 * np.pi * (day_of_year - 100) / 365)
    rainfall = np.where(np.random.random(n_samples) < rainfall_prob, 
                       np.random.exponential(2, n_samples), 0)
    
    # Generate pollutants with realistic correlations
    # PM2.5 (higher in winter, lower with wind/rain)
    pm25_base = 25 + 15 * np.sin(2 * np.pi * (day_of_year + 180) / 365)  # Higher in winter
    pm25_weather = -2 * wind_speed - 5 * (rainfall > 0) + 0.5 * humidity
    pm25 = pm25_base + pm25_weather + np.random.normal(0, 8, n_samples)
    pm25 = np.clip(pm25, 0, 200)
    
    # PM10 (correlated with PM2.5 but higher)
    pm10 = pm25 * 1.5 + np.random.normal(0, 10, n_samples)
    pm10 = np.clip(pm10, 0, 300)
    
    # NO2 (traffic-related, higher during rush hours)
    no2_traffic = 5 * (np.isin(hour_of_day, [7, 8, 9, 17, 18, 19]))
    no2_base = 20 + no2_traffic + np.random.normal(0, 8, n_samples)
    no2 = np.clip(no2_base, 0, 150)
    
    # SO2 (industrial, seasonal pattern)
    so2_base = 10 + 5 * np.sin(2 * np.pi * day_of_year / 365)
    so2 = so2_base + np.random.normal(0, 5, n_samples)
    so2 = np.clip(so2, 0, 100)
    
    # CO (traffic-related, inversely related to wind)
    co_base = 1.0 - 0.05 * wind_speed + 0.3 * (np.isin(hour_of_day, [7, 8, 9, 17, 18, 19]))
    co = co_base + np.random.normal(0, 0.3, n_samples)
    co = np.clip(co, 0, 10)
    
    # O3 (photochemical, higher in summer and midday)
    o3_seasonal = 40 + 20 * np.sin(2 * np.pi * day_of_year / 365)
    o3_daily = 15 * np.sin(2 * np.pi * (hour_of_day - 6) / 24)
    o3 = o3_seasonal + o3_daily + np.random.normal(0, 10, n_samples)
    o3 = np.clip(o3, 0, 200)
    
    # Calculate AQI based on pollutants (simplified calculation)
    def calculate_aqi(pm25, pm10, no2, so2, co, o3):
        # Simplified AQI calculation based on dominant pollutant
        aqi_pm25 = pm25 * 2  # PM2.5 breakpoints approximation
        aqi_pm10 = pm10 * 1.5
        aqi_no2 = no2 * 1.2
        aqi_so2 = so2 * 2
        aqi_co = co * 50
        aqi_o3 = o3 * 1.5
        
        return np.maximum.reduce([aqi_pm25, aqi_pm10, aqi_no2, aqi_so2, aqi_co, aqi_o3])
    
    aqi = calculate_aqi(pm25, pm10, no2, so2, co, o3)
    aqi = np.clip(aqi, 0, 500)
    
    # Create DataFrame
    df = pd.DataFrame({
        'datetime': dates,
        'temperature': np.round(temperature, 1),
        'humidity': np.round(humidity, 1),
        'wind_speed': np.round(wind_speed, 1),
        'pressure': np.round(pressure, 1),
        'rainfall': np.round(rainfall, 2),
        'pm25': np.round(pm25, 1),
        'pm10': np.round(pm10, 1),
        'no2': np.round(no2, 1),
        'so2': np.round(so2, 1),
        'co': np.round(co, 2),
        'o3': np.round(o3, 1),
        'aqi': np.round(aqi, 0).astype(int)
    })
    
    # Add some missing values randomly (5% missing)
    missing_cols = ['temperature', 'humidity', 'pm25', 'pm10', 'no2']
    for col in missing_cols:
        missing_idx = np.random.choice(df.index, size=int(0.05 * len(df)), replace=False)
        df.loc[missing_idx, col] = np.nan
    
    return df

# Generate and save dataset
print("Generating synthetic AQI dataset...")
df = generate_aqi_dataset(days=730)

# Save to CSV
df.to_csv('aqi_dataset.csv', index=False)

print(f"Dataset generated with {len(df)} samples")
print(f"Date range: {df['datetime'].min()} to {df['datetime'].max()}")
print("\nDataset info:")
print(df.info())
print("\nFirst few rows:")
print(df.head())
print("\nAQI statistics:")
print(df['aqi'].describe())
