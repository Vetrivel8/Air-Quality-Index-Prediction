import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score, classification_report
from sklearn.model_selection import cross_val_score
import joblib
import warnings
warnings.filterwarnings('ignore')

class ModelEvaluator:
    def __init__(self):
        self.models = {}
        self.results = {}
        
    def load_models(self):
        """Load all trained models"""
        try:
            # Load Random Forest
            rf_data = joblib.load('random_forest_model.joblib')
            self.models['Random Forest'] = {
                'model': rf_data['model'],
                'type': 'sklearn',
                'feature_columns': rf_data['feature_columns']
            }
            print("✓ Random Forest model loaded")
        except:
            print("✗ Random Forest model not found")
        
        try:
            # Load LSTM
            import tensorflow as tf
            lstm_model = tf.keras.models.load_model('lstm_model.h5')
            lstm_metadata = joblib.load('lstm_model_metadata.joblib')
            
            self.models['LSTM'] = {
                'model': lstm_model,
                'type': 'keras',
                'scaler_X': lstm_metadata['scaler_X'],
                'scaler_y': lstm_metadata['scaler_y'],
                'sequence_length': lstm_metadata['sequence_length'],
                'feature_columns': lstm_metadata['feature_columns']
            }
            print("✓ LSTM model loaded")
        except:
            print("✗ LSTM model not found")
    
    def load_data(self, filepath='aqi_processed.csv'):
        """Load preprocessed data"""
        df = pd.read_csv(filepath)
        df['datetime'] = pd.to_datetime(df['datetime'])
        return df.sort_values('datetime')
    
    def prepare_test_data(self, df, test_size=0.2):
        """Prepare test data for evaluation"""
        split_idx = int(len(df) * (1 - test_size))
        test_df = df.iloc[split_idx:].copy()
        return test_df
    
    def evaluate_random_forest(self, test_df):
        """Evaluate Random Forest model"""
        if 'Random Forest' not in self.models:
            return None
        
        model_info = self.models['Random Forest']
        model = model_info['model']
        feature_cols = model_info['feature_columns']
        
        X_test = test_df[feature_cols]
        y_test = test_df['aqi']
        
        # Predictions
        y_pred = model.predict(X_test)
        
        # Metrics
        metrics = self.calculate_metrics(y_test, y_pred)
        
        # AQI category evaluation
        y_test_cat = self.categorize_aqi(y_test)
        y_pred_cat = self.categorize_aqi(y_pred)
        
        return {
            'predictions': y_pred,
            'actual': y_test.values,
            'metrics': metrics,
            'actual_categories': y_test_cat,
            'predicted_categories': y_pred_cat,
            'feature_importance': model.feature_importances_
        }
    
    def evaluate_lstm(self, test_df):
        """Evaluate LSTM model"""
        if 'LSTM' not in self.models:
            return None
        
        model_info = self.models['LSTM']
        model = model_info['model']
        scaler_X = model_info['scaler_X']
        scaler_y = model_info['scaler_y']
        seq_length = model_info['sequence_length']
        feature_cols = model_info['feature_columns']
        
        # Prepare sequences
        X_data = test_df[feature_cols].values
        y_data = test_df['aqi'].values
        
        X_scaled = scaler_X.transform(X_data)
        
        # Create sequences
        X_sequences = []
        y_sequences = []
        
        for i in range(seq_length, len(X_scaled)):
            X_sequences.append(X_scaled[i-seq_length:i])
            y_sequences.append(y_data[i])
        
        X_sequences = np.array(X_sequences)
        y_sequences = np.array(y_sequences)
        
        # Predictions
        y_pred_scaled = model.predict(X_sequences)
        y_pred = scaler_y.inverse_transform(y_pred_scaled).flatten()
        
        # Metrics
        metrics = self.calculate_metrics(y_sequences, y_pred)
        
        # AQI category evaluation
        y_test_cat = self.categorize_aqi(y_sequences)
        y_pred_cat = self.categorize_aqi(y_pred)
        
        return {
            'predictions': y_pred,
            'actual': y_sequences,
            'metrics': metrics,
            'actual_categories': y_test_cat,
            'predicted_categories': y_pred_cat
        }
    
    def calculate_metrics(self, y_true, y_pred):
        """Calculate comprehensive evaluation metrics"""
        return {
            'RMSE': np.sqrt(mean_squared_error(y_true, y_pred)),
            'MAE': mean_absolute_error(y_true, y_pred),
            'R2': r2_score(y_true, y_pred),
            'MAPE': np.mean(np.abs((y_true - y_pred) / y_true)) * 100,
            'Max_Error': np.max(np.abs(y_true - y_pred)),
            'Mean_Residual': np.mean(y_true - y_pred)
        }
    
    def categorize_aqi(self, aqi_values):
        """Categorize AQI values"""
        categories = []
        for aqi in aqi_values:
            if aqi <= 50:
                categories.append('Good')
            elif aqi <= 100:
                categories.append('Moderate')
            elif aqi <= 200:
                categories.append('Poor')
            elif aqi <= 300:
                categories.append('Very Poor')
            else:
                categories.append('Severe')
        return categories
    
    def compare_models(self, test_df):
        """Compare all models"""
        print("=== MODEL COMPARISON ===\n")
        
        # Evaluate each model
        rf_results = self.evaluate_random_forest(test_df)
        lstm_results = self.evaluate_lstm(test_df)
        
        self.results = {
            'Random Forest': rf_results,
            'LSTM': lstm_results
        }
        
        # Print comparison table
        metrics_df = []
        
        for model_name, results in self.results.items():
            if results is not None:
                row = {'Model': model_name}
                row.update(results['metrics'])
                metrics_df.append(row)
        
        if metrics_df:
            comparison_df = pd.DataFrame(metrics_df)
            print("Performance Metrics Comparison:")
            print(comparison_df.round(4))
            print()
            
            # Find best model for each metric
            for metric in ['RMSE', 'MAE', 'R2', 'MAPE']:
                if metric == 'R2':
                    best_idx = comparison_df[metric].idxmax()
                else:
                    best_idx = comparison_df[metric].idxmin()
                best_model = comparison_df.loc[best_idx, 'Model']
                best_value = comparison_df.loc[best_idx, metric]
                print(f"Best {metric}: {best_model} ({best_value:.4f})")
        
        return self.results
    
    def plot_model_comparison(self):
        """Create comprehensive comparison plots"""
        if not self.results:
            print("No results to plot. Run compare_models first.")
            return
        
        # Filter out None results
        valid_results = {k: v for k, v in self.results.items() if v is not None}
        
        if len(valid_results) == 0:
            print("No valid results to plot.")
            return
        
        n_models = len(valid_results)
        fig, axes = plt.subplots(2, n_models, figsize=(6*n_models, 10))
        
        if n_models == 1:
            axes = axes.reshape(-1, 1)
        
        for i, (model_name, results) in enumerate(valid_results.items()):
            y_true = results['actual']
            y_pred = results['predictions']
            
            # Scatter plot
            axes[0, i].scatter(y_true, y_pred, alpha=0.6, s=20)
            axes[0, i].plot([y_true.min(), y_true.max()], 
                           [y_true.min(), y_true.max()], 'r--', lw=2)
            axes[0, i].set_xlabel('Actual AQI')
            axes[0, i].set_ylabel('Predicted AQI')
            axes[0, i].set_title(f'{model_name}\nR² = {results["metrics"]["R2"]:.3f}')
            axes[0, i].grid(True, alpha=0.3)
            
            # Residuals plot
            residuals = y_true - y_pred
            axes[1, i].scatter(y_pred, residuals, alpha=0.6, s=20)
            axes[1, i].axhline(y=0, color='r', linestyle='--', lw=2)
            axes[1, i].set_xlabel('Predicted AQI')
            axes[1, i].set_ylabel('Residuals')
            axes[1, i].set_title(f'{model_name} Residuals\nMAE = {results["metrics"]["MAE"]:.3f}')
            axes[1, i].grid(True, alpha=0.3)
        
        plt.tight_layout()
        plt.savefig('model_comparison.png', dpi=300, bbox_inches='tight')
        plt.show()
    
    def plot_category_performance(self):
        """Plot AQI category classification performance"""
        if not self.results:
            return
        
        valid_results = {k: v for k, v in self.results.items() if v is not None}
        
        fig, axes = plt.subplots(1, len(valid_results), figsize=(6*len(valid_results), 5))
        
        if len(valid_results) == 1:
            axes = [axes]
        
        for i, (model_name, results) in enumerate(valid_results.items()):
            # Classification report
            from sklearn.metrics import confusion_matrix
            
            cm = confusion_matrix(results['actual_categories'], 
                                results['predicted_categories'],
                                labels=['Good', 'Moderate', 'Poor', 'Very Poor', 'Severe'])
            
            sns.heatmap(cm, annot=True, fmt='d', cmap='Blues',
                       xticklabels=['Good', 'Moderate', 'Poor', 'Very Poor', 'Severe'],
                       yticklabels=['Good', 'Moderate', 'Poor', 'Very Poor', 'Severe'],
                       ax=axes[i])
            axes[i].set_title(f'{model_name} - AQI Category Confusion Matrix')
            axes[i].set_xlabel('Predicted Category')
            axes[i].set_ylabel('Actual Category')
        
        plt.tight_layout()
        plt.savefig('category_performance.png', dpi=300, bbox_inches='tight')
        plt.show()
    
    def plot_time_series_comparison(self, n_points=200):
        """Plot time series predictions"""
        if not self.results:
            return
        
        valid_results = {k: v for k, v in self.results.items() if v is not None}
        
        plt.figure(figsize=(15, 8))
        
        for model_name, results in valid_results.items():
            y_true = results['actual'][-n_points:]
            y_pred = results['predictions'][-n_points:]
            
            plt.plot(y_true, label=f'Actual', alpha=0.8, linewidth=2)
            plt.plot(y_pred, label=f'{model_name} Predicted', alpha=0.8, linewidth=1.5)
        
        plt.xlabel('Time Steps')
        plt.ylabel('AQI')
        plt.title(f'Time Series Prediction Comparison (Last {n_points} points)')
        plt.legend()
        plt.grid(True, alpha=0.3)
        plt.tight_layout()
        plt.savefig('time_series_comparison.png', dpi=300, bbox_inches='tight')
        plt.show()
    
    def generate_evaluation_report(self):
        """Generate comprehensive evaluation report"""
        if not self.results:
            print("No results available. Run compare_models first.")
            return
        
        report = []
        report.append("=" * 60)
        report.append("AQI PREDICTION MODEL EVALUATION REPORT")
        report.append("=" * 60)
        report.append("")
        
        valid_results = {k: v for k, v in self.results.items() if v is not None}
        
        for model_name, results in valid_results.items():
            report.append(f"--- {model_name.upper()} MODEL ---")
            report.append("")
            
            # Regression metrics
            report.append("Regression Metrics:")
            for metric, value in results['metrics'].items():
                report.append(f"  {metric}: {value:.4f}")
            report.append("")
            
            # Classification report
            from sklearn.metrics import classification_report
            class_report = classification_report(
                results['actual_categories'], 
                results['predicted_categories'],
                target_names=['Good', 'Moderate', 'Poor', 'Very Poor', 'Severe']
            )
            report.append("AQI Category Classification Report:")
            report.append(class_report)
            report.append("")
        
        # Model recommendation
        if len(valid_results) > 1:
            # Find best model based on R2 score
            best_model = max(valid_results.keys(), 
                           key=lambda x: valid_results[x]['metrics']['R2'])
            report.append("RECOMMENDATION:")
            report.append(f"Based on R² score, {best_model} performs best for AQI prediction.")
            report.append("")
        
        report_text = "\n".join(report)
        
        # Save report
        with open('evaluation_report.txt', 'w') as f:
            f.write(report_text)
        
        print(report_text)
        print("✓ Evaluation report saved to 'evaluation_report.txt'")

# Main execution
if __name__ == "__main__":
    # Initialize evaluator
    evaluator = ModelEvaluator()
    
    # Load models
    evaluator.load_models()
    
    # Load test data
    df = evaluator.load_data()
    test_df = evaluator.prepare_test_data(df)
    print(f"Test dataset shape: {test_df.shape}")
    
    # Compare models
    results = evaluator.compare_models(test_df)
    
    # Generate plots
    evaluator.plot_model_comparison()
    evaluator.plot_category_performance()
    evaluator.plot_time_series_comparison()
    
    # Generate report
    evaluator.generate_evaluation_report()
    
    print("\n✓ Model evaluation completed!")
