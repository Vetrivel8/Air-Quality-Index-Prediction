import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler, MinMaxScaler
from sklearn.impute import SimpleImputer
import joblib
import warnings
warnings.filterwarnings('ignore')

class AQIDataPreprocessor:
    def __init__(self):
        self.scaler = StandardScaler()
        self.imputer = SimpleImputer(strategy='median')
        self.feature_columns = None
        self.target_column = 'aqi'
        
    def load_data(self, filepath):
        """Load data from CSV file"""
        df = pd.read_csv(filepath)
        df['datetime'] = pd.to_datetime(df['datetime'])
        return df
    
    def create_time_features(self, df):
        """Create time-based features"""
        df = df.copy()
        df['hour'] = df['datetime'].dt.hour
        df['day_of_week'] = df['datetime'].dt.dayofweek
        df['month'] = df['datetime'].dt.month
        df['day_of_year'] = df['datetime'].dt.dayofyear
        
        # Cyclical encoding for time features
        df['hour_sin'] = np.sin(2 * np.pi * df['hour'] / 24)
        df['hour_cos'] = np.cos(2 * np.pi * df['hour'] / 24)
        df['day_sin'] = np.sin(2 * np.pi * df['day_of_week'] / 7)
        df['day_cos'] = np.cos(2 * np.pi * df['day_of_week'] / 7)
        df['month_sin'] = np.sin(2 * np.pi * df['month'] / 12)
        df['month_cos'] = np.cos(2 * np.pi * df['month'] / 12)
        
        return df
    
    def create_lag_features(self, df, lag_hours=[1, 3, 6, 12, 24]):
        """Create lagged features for time series"""
        df = df.copy()
        df = df.sort_values('datetime')
        
        pollutant_cols = ['pm25', 'pm10', 'no2', 'so2', 'co', 'o3']
        weather_cols = ['temperature', 'humidity', 'wind_speed']
        
        for col in pollutant_cols + weather_cols:
            for lag in lag_hours:
                df[f'{col}_lag_{lag}h'] = df[col].shift(lag)
        
        # Rolling averages
        for col in pollutant_cols:
            df[f'{col}_rolling_3h'] = df[col].rolling(window=3, min_periods=1).mean()
            df[f'{col}_rolling_6h'] = df[col].rolling(window=6, min_periods=1).mean()
            df[f'{col}_rolling_24h'] = df[col].rolling(window=24, min_periods=1).mean()
        
        return df
    
    def create_interaction_features(self, df):
        """Create interaction features"""
        df = df.copy()
        
        # Weather interactions
        df['temp_humidity'] = df['temperature'] * df['humidity']
        df['wind_rainfall'] = df['wind_speed'] * df['rainfall']
        
        # Pollutant ratios
        df['pm25_pm10_ratio'] = df['pm25'] / (df['pm10'] + 1e-6)
        df['no2_o3_ratio'] = df['no2'] / (df['o3'] + 1e-6)
        
        return df
    
    def handle_missing_values(self, df, fit=True):
        """Handle missing values using imputation"""
        numeric_cols = df.select_dtypes(include=[np.number]).columns
        numeric_cols = [col for col in numeric_cols if col != self.target_column]
        
        if fit:
            df[numeric_cols] = self.imputer.fit_transform(df[numeric_cols])
        else:
            df[numeric_cols] = self.imputer.transform(df[numeric_cols])
        
        return df
    
    def scale_features(self, df, fit=True):
        """Scale features using StandardScaler"""
        if self.feature_columns is None:
            self.feature_columns = [col for col in df.columns 
                                  if col not in ['datetime', self.target_column]]
        
        if fit:
            df[self.feature_columns] = self.scaler.fit_transform(df[self.feature_columns])
        else:
            df[self.feature_columns] = self.scaler.transform(df[self.feature_columns])
        
        return df
    
    def categorize_aqi(self, aqi_values):
        """Categorize AQI values into standard categories"""
        categories = []
        for aqi in aqi_values:
            if aqi <= 50:
                categories.append('Good')
            elif aqi <= 100:
                categories.append('Moderate')
            elif aqi <= 200:
                categories.append('Poor')
            elif aqi <= 300:
                categories.append('Very Poor')
            else:
                categories.append('Severe')
        return categories
    
    def preprocess_data(self, df, fit=True):
        """Complete preprocessing pipeline"""
        print("Starting data preprocessing...")
        
        # Create time-based features
        df = self.create_time_features(df)
        print("✓ Time features created")
        
        # Create lag features
        df = self.create_lag_features(df)
        print("✓ Lag features created")
        
        # Create interaction features
        df = self.create_interaction_features(df)
        print("✓ Interaction features created")
        
        # Handle missing values
        df = self.handle_missing_values(df, fit=fit)
        print("✓ Missing values handled")
        
        # Scale features
        df = self.scale_features(df, fit=fit)
        print("✓ Features scaled")
        
        # Add AQI categories
        df['aqi_category'] = self.categorize_aqi(df[self.target_column])
        
        # Remove rows with NaN values (from lag features)
        df = df.dropna()
        
        print(f"✓ Preprocessing complete. Final dataset shape: {df.shape}")
        return df
    
    def save_preprocessor(self, filepath='preprocessor.joblib'):
        """Save the fitted preprocessor"""
        joblib.dump({
            'scaler': self.scaler,
            'imputer': self.imputer,
            'feature_columns': self.feature_columns
        }, filepath)
        print(f"✓ Preprocessor saved to {filepath}")
    
    def load_preprocessor(self, filepath='preprocessor.joblib'):
        """Load a fitted preprocessor"""
        components = joblib.load(filepath)
        self.scaler = components['scaler']
        self.imputer = components['imputer']
        self.feature_columns = components['feature_columns']
        print(f"✓ Preprocessor loaded from {filepath}")

# Main execution
if __name__ == "__main__":
    # Initialize preprocessor
    preprocessor = AQIDataPreprocessor()
    
    # Load data
    df = preprocessor.load_data('aqi_dataset.csv')
    print(f"Original dataset shape: {df.shape}")
    
    # Preprocess data
    df_processed = preprocessor.preprocess_data(df, fit=True)
    
    # Save processed data
    df_processed.to_csv('aqi_processed.csv', index=False)
    
    # Save preprocessor
    preprocessor.save_preprocessor()
    
    print("\nPreprocessed dataset info:")
    print(df_processed.info())
    print(f"\nFeature columns ({len(preprocessor.feature_columns)}):")
    print(preprocessor.feature_columns[:10], "...")  # Show first 10 features
