import pandas as pd
import numpy as np
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense, Dropout, BatchNormalization
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.callbacks import EarlyStopping, ReduceLROnPlateau
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
import joblib
import matplotlib.pyplot as plt

class LSTMAQIModel:
    def __init__(self, sequence_length=24):
        self.model = None
        self.sequence_length = sequence_length
        self.scaler_X = MinMaxScaler()
        self.scaler_y = MinMaxScaler()
        self.feature_columns = None
        
    def load_data(self, filepath='aqi_processed.csv'):
        """Load preprocessed data"""
        df = pd.read_csv(filepath)
        df['datetime'] = pd.to_datetime(df['datetime'])
        return df.sort_values('datetime')
    
    def prepare_sequences(self, df):
        """Prepare sequences for LSTM training"""
        # Select features (exclude datetime and categorical columns)
        feature_cols = [col for col in df.columns 
                       if col not in ['datetime', 'aqi_category']]
        
        # Separate features and target
        X_cols = [col for col in feature_cols if col != 'aqi']
        y_col = 'aqi'
        
        self.feature_columns = X_cols
        
        # Scale the data
        X_scaled = self.scaler_X.fit_transform(df[X_cols])
        y_scaled = self.scaler_y.fit_transform(df[[y_col]])
        
        # Create sequences
        X_sequences = []
        y_sequences = []
        
        for i in range(self.sequence_length, len(X_scaled)):
            X_sequences.append(X_scaled[i-self.sequence_length:i])
            y_sequences.append(y_scaled[i])
        
        return np.array(X_sequences), np.array(y_sequences)
    
    def build_model(self, input_shape):
        """Build LSTM model architecture"""
        model = Sequential([
            LSTM(128, return_sequences=True, input_shape=input_shape),
            Dropout(0.2),
            BatchNormalization(),
            
            LSTM(64, return_sequences=True),
            Dropout(0.2),
            BatchNormalization(),
            
            LSTM(32, return_sequences=False),
            Dropout(0.2),
            BatchNormalization(),
            
            Dense(16, activation='relu'),
            Dropout(0.1),
            Dense(1)
        ])
        
        model.compile(
            optimizer=Adam(learning_rate=0.001),
            loss='mse',
            metrics=['mae']
        )
        
        return model
    
    def train_model(self, X, y, test_size=0.2, epochs=100, batch_size=32):
        """Train LSTM model"""
        print("Preparing LSTM training data...")
        
        # Split data (time series split - no shuffling)
        split_idx = int(len(X) * (1 - test_size))
        X_train, X_test = X[:split_idx], X[split_idx:]
        y_train, y_test = y[:split_idx], y[split_idx:]
        
        print(f"Training sequences: {X_train.shape}")
        print(f"Testing sequences: {X_test.shape}")
        
        # Build model
        self.model = self.build_model((X_train.shape[1], X_train.shape[2]))
        print("LSTM model architecture:")
        self.model.summary()
        
        # Callbacks
        callbacks = [
            EarlyStopping(patience=15, restore_best_weights=True),
            ReduceLROnPlateau(patience=10, factor=0.5, min_lr=1e-7)
        ]
        
        # Train model
        print("Training LSTM model...")
        history = self.model.fit(
            X_train, y_train,
            validation_data=(X_test, y_test),
            epochs=epochs,
            batch_size=batch_size,
            callbacks=callbacks,
            verbose=1
        )
        
        # Make predictions
        y_train_pred_scaled = self.model.predict(X_train)
        y_test_pred_scaled = self.model.predict(X_test)
        
        # Inverse transform predictions
        y_train_pred = self.scaler_y.inverse_transform(y_train_pred_scaled)
        y_test_pred = self.scaler_y.inverse_transform(y_test_pred_scaled)
        y_train_actual = self.scaler_y.inverse_transform(y_train)
        y_test_actual = self.scaler_y.inverse_transform(y_test)
        
        # Calculate metrics
        train_metrics = self.calculate_metrics(y_train_actual.flatten(), y_train_pred.flatten())
        test_metrics = self.calculate_metrics(y_test_actual.flatten(), y_test_pred.flatten())
        
        print("\n=== LSTM Model Performance ===")
        print("Training Metrics:")
        for metric, value in train_metrics.items():
            print(f"  {metric}: {value:.4f}")
        
        print("\nTesting Metrics:")
        for metric, value in test_metrics.items():
            print(f"  {metric}: {value:.4f}")
        
        return {
            'history': history,
            'train_metrics': train_metrics,
            'test_metrics': test_metrics,
            'y_test_actual': y_test_actual.flatten(),
            'y_test_pred': y_test_pred.flatten()
        }
    
    def calculate_metrics(self, y_true, y_pred):
        """Calculate evaluation metrics"""
        return {
            'RMSE': np.sqrt(mean_squared_error(y_true, y_pred)),
            'MAE': mean_absolute_error(y_true, y_pred),
            'R2': r2_score(y_true, y_pred)
        }
    
    def plot_training_history(self, history):
        """Plot training history"""
        plt.figure(figsize=(12, 4))
        
        plt.subplot(1, 2, 1)
        plt.plot(history.history['loss'], label='Training Loss')
        plt.plot(history.history['val_loss'], label='Validation Loss')
        plt.title('Model Loss')
        plt.xlabel('Epoch')
        plt.ylabel('Loss')
        plt.legend()
        
        plt.subplot(1, 2, 2)
        plt.plot(history.history['mae'], label='Training MAE')
        plt.plot(history.history['val_mae'], label='Validation MAE')
        plt.title('Model MAE')
        plt.xlabel('Epoch')
        plt.ylabel('MAE')
        plt.legend()
        
        plt.tight_layout()
        plt.savefig('lstm_training_history.png', dpi=300, bbox_inches='tight')
        plt.show()
    
    def plot_predictions(self, y_true, y_pred, title="LSTM Predictions"):
        """Plot actual vs predicted values"""
        plt.figure(figsize=(15, 5))
        
        plt.subplot(1, 3, 1)
        plt.scatter(y_true, y_pred, alpha=0.5)
        plt.plot([y_true.min(), y_true.max()], [y_true.min(), y_true.max()], 'r--', lw=2)
        plt.xlabel('Actual AQI')
        plt.ylabel('Predicted AQI')
        plt.title(f'{title} - Scatter Plot')
        
        plt.subplot(1, 3, 2)
        residuals = y_true - y_pred
        plt.scatter(y_pred, residuals, alpha=0.5)
        plt.axhline(y=0, color='r', linestyle='--')
        plt.xlabel('Predicted AQI')
        plt.ylabel('Residuals')
        plt.title(f'{title} - Residuals')
        
        plt.subplot(1, 3, 3)
        # Time series plot (last 200 points)
        n_points = min(200, len(y_true))
        plt.plot(y_true[-n_points:], label='Actual', alpha=0.7)
        plt.plot(y_pred[-n_points:], label='Predicted', alpha=0.7)
        plt.xlabel('Time Steps')
        plt.ylabel('AQI')
        plt.title(f'{title} - Time Series')
        plt.legend()
        
        plt.tight_layout()
        plt.savefig('lstm_predictions.png', dpi=300, bbox_inches='tight')
        plt.show()
    
    def save_model(self, filepath='lstm_model'):
        """Save the trained model"""
        # Save Keras model
        self.model.save(f'{filepath}.h5')
        
        # Save scalers and metadata
        model_data = {
            'scaler_X': self.scaler_X,
            'scaler_y': self.scaler_y,
            'sequence_length': self.sequence_length,
            'feature_columns': self.feature_columns
        }
        joblib.dump(model_data, f'{filepath}_metadata.joblib')
        print(f"✓ LSTM model saved to {filepath}.h5 and {filepath}_metadata.joblib")
    
    def load_model(self, filepath='lstm_model'):
        """Load a trained model"""
        # Load Keras model
        self.model = tf.keras.models.load_model(f'{filepath}.h5')
        
        # Load scalers and metadata
        model_data = joblib.load(f'{filepath}_metadata.joblib')
        self.scaler_X = model_data['scaler_X']
        self.scaler_y = model_data['scaler_y']
        self.sequence_length = model_data['sequence_length']
        self.feature_columns = model_data['feature_columns']
        print(f"✓ LSTM model loaded from {filepath}")
    
    def predict_sequence(self, X_sequence):
        """Make prediction for a single sequence"""
        if self.model is None:
            raise ValueError("Model not trained or loaded")
        
        X_scaled = self.scaler_X.transform(X_sequence)
        X_seq = X_scaled.reshape(1, X_scaled.shape[0], X_scaled.shape[1])
        y_pred_scaled = self.model.predict(X_seq)
        y_pred = self.scaler_y.inverse_transform(y_pred_scaled)
        
        return y_pred[0][0]

# Main execution
if __name__ == "__main__":
    # Initialize model
    lstm_model = LSTMAQIModel(sequence_length=24)
    
    # Load data
    df = lstm_model.load_data()
    print(f"Loaded dataset shape: {df.shape}")
    
    # Prepare sequences
    X, y = lstm_model.prepare_sequences(df)
    print(f"Sequences shape: X={X.shape}, y={y.shape}")
    
    # Train model
    results = lstm_model.train_model(X, y, epochs=50)
    
    # Plot results
    lstm_model.plot_training_history(results['history'])
    lstm_model.plot_predictions(results['y_test_actual'], results['y_test_pred'])
    
    # Save model
    lstm_model.save_model()
    
    print("\n✓ LSTM model training completed!")
