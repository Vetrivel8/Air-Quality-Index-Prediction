import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
import joblib
import matplotlib.pyplot as plt
import seaborn as sns

class RandomForestAQIModel:
    def __init__(self):
        self.model = None
        self.feature_importance = None
        self.feature_columns = None
        
    def load_data(self, filepath='aqi_processed.csv'):
        """Load preprocessed data"""
        df = pd.read_csv(filepath)
        return df
    
    def prepare_data(self, df):
        """Prepare features and target"""
        # Remove non-feature columns
        feature_cols = [col for col in df.columns 
                       if col not in ['datetime', 'aqi', 'aqi_category']]
        
        X = df[feature_cols]
        y = df['aqi']
        
        self.feature_columns = feature_cols
        return X, y
    
    def train_model(self, X, y, test_size=0.2, random_state=42):
        """Train Random Forest model with hyperparameter tuning"""
        print("Splitting data...")
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=test_size, random_state=random_state, shuffle=False
        )
        
        print("Training Random Forest model...")
        
        # Define parameter grid for tuning
        param_grid = {
            'n_estimators': [100, 200, 300],
            'max_depth': [10, 20, None],
            'min_samples_split': [2, 5, 10],
            'min_samples_leaf': [1, 2, 4]
        }
        
        # Initialize base model
        rf = RandomForestRegressor(random_state=random_state, n_jobs=-1)
        
        # Grid search with cross-validation
        print("Performing hyperparameter tuning...")
        grid_search = GridSearchCV(
            rf, param_grid, cv=3, scoring='neg_mean_squared_error', 
            n_jobs=-1, verbose=1
        )
        
        grid_search.fit(X_train, y_train)
        
        # Best model
        self.model = grid_search.best_estimator_
        print(f"Best parameters: {grid_search.best_params_}")
        
        # Feature importance
        self.feature_importance = pd.DataFrame({
            'feature': self.feature_columns,
            'importance': self.model.feature_importances_
        }).sort_values('importance', ascending=False)
        
        # Predictions
        y_train_pred = self.model.predict(X_train)
        y_test_pred = self.model.predict(X_test)
        
        # Calculate metrics
        train_metrics = self.calculate_metrics(y_train, y_train_pred)
        test_metrics = self.calculate_metrics(y_test, y_test_pred)
        
        print("\n=== Random Forest Model Performance ===")
        print("Training Metrics:")
        for metric, value in train_metrics.items():
            print(f"  {metric}: {value:.4f}")
        
        print("\nTesting Metrics:")
        for metric, value in test_metrics.items():
            print(f"  {metric}: {value:.4f}")
        
        return {
            'train_metrics': train_metrics,
            'test_metrics': test_metrics,
            'X_test': X_test,
            'y_test': y_test,
            'y_test_pred': y_test_pred
        }
    
    def calculate_metrics(self, y_true, y_pred):
        """Calculate evaluation metrics"""
        return {
            'RMSE': np.sqrt(mean_squared_error(y_true, y_pred)),
            'MAE': mean_absolute_error(y_true, y_pred),
            'R2': r2_score(y_true, y_pred)
        }
    
    def plot_feature_importance(self, top_n=20):
        """Plot feature importance"""
        plt.figure(figsize=(10, 8))
        top_features = self.feature_importance.head(top_n)
        
        sns.barplot(data=top_features, x='importance', y='feature')
        plt.title(f'Top {top_n} Feature Importance - Random Forest')
        plt.xlabel('Importance')
        plt.tight_layout()
        plt.savefig('rf_feature_importance.png', dpi=300, bbox_inches='tight')
        plt.show()
    
    def plot_predictions(self, y_true, y_pred, title="Random Forest Predictions"):
        """Plot actual vs predicted values"""
        plt.figure(figsize=(10, 6))
        
        plt.subplot(1, 2, 1)
        plt.scatter(y_true, y_pred, alpha=0.5)
        plt.plot([y_true.min(), y_true.max()], [y_true.min(), y_true.max()], 'r--', lw=2)
        plt.xlabel('Actual AQI')
        plt.ylabel('Predicted AQI')
        plt.title(f'{title} - Scatter Plot')
        
        plt.subplot(1, 2, 2)
        residuals = y_true - y_pred
        plt.scatter(y_pred, residuals, alpha=0.5)
        plt.axhline(y=0, color='r', linestyle='--')
        plt.xlabel('Predicted AQI')
        plt.ylabel('Residuals')
        plt.title(f'{title} - Residuals')
        
        plt.tight_layout()
        plt.savefig('rf_predictions.png', dpi=300, bbox_inches='tight')
        plt.show()
    
    def save_model(self, filepath='random_forest_model.joblib'):
        """Save the trained model"""
        model_data = {
            'model': self.model,
            'feature_columns': self.feature_columns,
            'feature_importance': self.feature_importance
        }
        joblib.dump(model_data, filepath)
        print(f"✓ Random Forest model saved to {filepath}")
    
    def load_model(self, filepath='random_forest_model.joblib'):
        """Load a trained model"""
        model_data = joblib.load(filepath)
        self.model = model_data['model']
        self.feature_columns = model_data['feature_columns']
        self.feature_importance = model_data['feature_importance']
        print(f"✓ Random Forest model loaded from {filepath}")
    
    def predict(self, X):
        """Make predictions"""
        if self.model is None:
            raise ValueError("Model not trained or loaded")
        return self.model.predict(X)

# Main execution
if __name__ == "__main__":
    # Initialize model
    rf_model = RandomForestAQIModel()
    
    # Load data
    df = rf_model.load_data()
    print(f"Loaded dataset shape: {df.shape}")
    
    # Prepare data
    X, y = rf_model.prepare_data(df)
    print(f"Features shape: {X.shape}, Target shape: {y.shape}")
    
    # Train model
    results = rf_model.train_model(X, y)
    
    # Plot results
    rf_model.plot_feature_importance()
    rf_model.plot_predictions(results['y_test'], results['y_test_pred'])
    
    # Save model
    rf_model.save_model()
    
    print("\n✓ Random Forest model training completed!")
